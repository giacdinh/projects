#ifndef __CONFIGh
#define __CONFIGh

#ifdef __cplusplus
extern "C"  {
#endif

#define RFR_CONFIG_FILE "/mnt/system/config/config.json"
#define CONFIG_FILE_SZ	2048
#define MAX_CONFIG_SZ	64	

typedef enum {
	READ_SPEED,
	READER_TIMEOUT,
	READER_POWER,
	READER_TZONE,
	READER_ZONE,
	READER_MODE,
	READER_PORT,
	END_OF_INT_FIELD, // All fields below will be string value
	READER_TYPE,
	READER_LOCATION,
	ANT_1,
	ANT_2,
	ANT_3,
	ANT_4,
	ANT_5,
	ANT_6,
	ANT_7,
	ANT_8,
	USER_NAME,
	PASS_WD,
	DBASE_NAME,
	TABLE_NAME,
	GPS,
	CAMERA,
	SCALE,
	SSID1,
	PASSWD1,
	SSID2,
	PASSWD2,
	CONFIG_ENUM_UNKNOWN
} CONFIG_ENUM;

char CONFIG_FIELD[CONFIG_ENUM_UNKNOWN][MAX_CONFIG_SZ] = {
	"read_speed",
	"reader_timeout",
	"reader_power",
	"reader_tzone",
	"reader_zone",
	"reader_mode",
	"reader_port",
	"endofintfield", // All fields below will be string value
	"reader_type",
	"location",
	"ant1",
	"ant2",
	"ant3",
	"ant4",
	"ant5",
	"ant6",
	"ant7",
	"ant8",
	"user",
	"pass",
	"dbase",
	"table",
	"gps",
	"camera",
	"scale",
	"ssid1",
	"passwd1",
	"ssid2",
	"passwd2"
};

typedef struct {
	int read_speed;
	int reader_tout;
	int reader_power;
	int reader_tzone;
	int reader_zone;
	int reader_mode;
	int reader_port;
	int endofint;
	char reader_type[MAX_CONFIG_SZ];
	char location[MAX_CONFIG_SZ];
	char ant_1[MAX_CONFIG_SZ];
	char ant_2[MAX_CONFIG_SZ];
	char ant_3[MAX_CONFIG_SZ];
	char ant_4[MAX_CONFIG_SZ];
	char ant_5[MAX_CONFIG_SZ];
	char ant_6[MAX_CONFIG_SZ];
	char ant_7[MAX_CONFIG_SZ];
	char ant_8[MAX_CONFIG_SZ];
	char user[MAX_CONFIG_SZ];
	char pass[MAX_CONFIG_SZ];
	char dbase[MAX_CONFIG_SZ];
	char table[MAX_CONFIG_SZ];
	char gps[MAX_CONFIG_SZ];
	char camera[MAX_CONFIG_SZ];
	char scale[MAX_CONFIG_SZ];
	char ssid1[MAX_CONFIG_SZ];
	char passwd1[MAX_CONFIG_SZ];
	char ssid2[MAX_CONFIG_SZ];
	char passwd2[MAX_CONFIG_SZ];
} CONFIG_T;	


#endif
