#ifndef _VERSION_H
#define _VERSION_H

#include "../build.h"

#define MAIN_VERSION "1.0.1.1"

//#define USE_TM_READER

#ifdef USE_TM_READER
#define READER_HW " TM_READER"
#else
#define READER_HW " RDB_READER"
#endif

#define RUN_VERSION MAIN_VERSION READER_HW SVNREV

#endif
