

#ifndef __INCSYSMSGh
#define __INCSYSMSGh

#ifdef __cplusplus
extern "C"  {
#endif

#include <sys/msg.h>
#include <sys/ipc.h>

#define GENERIC_MSG_HANDLE_DELAY	100000 // 100 Ms
// Define each module message key value
#define WD_MSGQ_KEY			0x00002222
#define GPS_MSGQ_KEY		0x00003333
#define REMOTEM_MSGQ_KEY	0x00004444
#define CTRL_MSGQ_KEY		0x00005555
#define DBASE_MSGQ_KEY		0x00006666
#define READER_MSGQ_KEY		0x00007777
#define CONFIG_MSGQ_KEY		0x00008888
#define SU_MSGQ_KEY			0x00009999

#define SYS_MSG_TYPE 0xf1a322

#define MSG_TIMEOUT 5 /* Try 5 second before read timeout */

#define TAG_NAMEDPIPE  "/tmp/tags_block" /* Named pipe to pass tag between process */

#define TAG_HEADER_SIGN	0x02010403
#define FULL_TAG_SIZE	64
#define SHAREMEM_SZ		512 

#define MAX_NUM_TAG     750
#define TAG_SIZE        64
#define TAGPOOL_SZ	2048

typedef struct {
    int tagCnt;
    char Tags[MAX_NUM_TAG][TAG_SIZE];
} RASPI_TAG_T;


typedef enum {
    GPS_MODULE_ID,
    REMOTEM_MODULE_ID,
    CTRL_MODULE_ID,
    DBASE_MODULE_ID,
    READER_MODULE_ID,
    CONFIG_MODULE_ID,
    SU_MODULE_ID,
    UNKNOWN_MODULE_ID
} MODULE_ID_ENUM;

typedef enum {
    MSG_BARK=0,
    MSG_TAG,
    MSG_CTRL_HANDHELD_READ,
    MSG_TAG_MOBILE_READ,
    MSG_MOBILE_SCAN_TAG,
    MSG_REMOTEM_TAG_READ,
    MSG_REMOTEM_HANDHELD_READ,
    MSG_REMOTEM_REPEAT_READ,
    MSG_REMOTEM_REPEAT_STOP,
    MSG_REMOTEM_CONFIG_SET_POWER,
    MSG_REMOTEM_CONFIG_SET_REGION,
    MSG_SU_START,
    MSG_SU_SHUTDOWN,
    MSG_READER_RSPEED,
    MSG_READER_POWER,
    MSG_READER_RTIMEOUT,
    MSG_REBOOT,
    MSG_INVALID
} MSG_TYPE_ENUM;

typedef struct {
    MODULE_ID_ENUM     moduleID;     /* sender's module ID */
    MSG_TYPE_ENUM      subType;      /* message command */
    unsigned long	   msgtime;	 /* For watchdog time keeper */
    int			   data;
} GENERIC_MSG_HEADER_T;

///* generic container that the above common messages will be delivered in  */
typedef struct {
    GENERIC_MSG_HEADER_T header;
	int value;
	int port;
	int ant;
} READER_MSG_T;

#ifdef NOTUSE
typedef struct {
    GENERIC_MSG_HEADER_T header;
	unsigned char tag[128];
    int epcLen;
    int antenna;
    int rssi;
	int freq;
} DBASE_MSG_T;

typedef struct {
    GENERIC_MSG_HEADER_T header;
	unsigned char tag[128];
    int epcLen;
    int antenna;
    int rssi;
	int freq;
} TAGS_MSG_T;
#endif

typedef struct {
    GENERIC_MSG_HEADER_T header;
	char filename[128];
} SU_MSG_T;

typedef struct {
    GENERIC_MSG_HEADER_T header;
} REMOTEM_MSG_T;

typedef struct {
    GENERIC_MSG_HEADER_T header;
} CTRL_MSG_T;

typedef struct {
    GENERIC_MSG_HEADER_T header;
} CONFIG_MSG_T;

typedef enum {
    DBG_ERROR = 0,
    DBG_DBG = 0,
    DBG_WARNING,
    DBG_EVENT,
    DBG_INFO,
    DBG_DETAILED,
	DBG_TAG,
    DBG_ALL
} LOG_LEVEL_ENUM_T;

typedef struct {
    unsigned int module_id;
    int     timer;
    int     reboot;
} WD_RESPONSE_T;


/***********************************************************************/
/* This part is definition of common tag's information */
typedef struct {
    int header_sign;
    unsigned char EPC[64];
} GEN2_TAG_T;

typedef struct {
    GENERIC_MSG_HEADER_T header;
    int tagcnt;
    char Tagpool[TAGPOOL_SZ];
} DBASE_MSG_T;
/***********************************************************************/

int create_msg(key_t p_key);
int send_msg(int msgid, void *msg, int size, int timeout);
int recv_msg(int msgid, void *msg, int size, int timeout);
void send_dog_bark(int);
int logging(int level, char *logstr, ...);
int open_msg(key_t key);

extern char *module_list[];
extern char *modname[];


#endif
