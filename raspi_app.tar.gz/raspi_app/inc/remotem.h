
#define RFR_REMOTEM_PORT	9999

#define GENERAL_RESPONSE_HEADER "HTTP/1.0 200 OK\r\n\
Content-type: text/plain; charset=iso-8859-1\r\n\r\n"


#define REMOTEM_SYS_SHUTDOWN		"remotem_sys_shutdown.cgi"
#define REMOTEM_SYS_REBOOT			"remotem_sys_reboot.cgi"
#define REMOTEM_SYS_CLKSYNC			"remotem_sys_clksync.cgi"
#define REMOTEM_TAG_READ			"remotem_tag_read.cgi"
#define REMOTEM_REPEAT_READ			"remotem_repeat_read.cgi"
#define REMOTEM_REPEAT_STOP			"remotem_repeat_stop.cgi"
#define REMOTEM_HANDHELD_READ		"remotem_handheld_read.cgi"
#define REMOTEM_SET_ANTENNA			"remotem_set_antenna.cgi"
#define REMOTEM_SET_REGION			"remotem_set_region.cgi"
#define REMOTEM_SET_POWER			"remotem_set_power.cgi"
#define REMOTEM_GET_UID				"remotem_get_uid.cgi"
#define REMOTEM_SU_START			"remotem_su_start.cgi"


