#include <stdio.h>
#include <pthread.h>
#include <sys_msg.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/prctl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include "inc/version.h"


extern void *wdog_main_task();
extern void *gps_main_task();
extern void *remotem_main_task();
extern void *ctrl_main_task();
extern void *reader_main_task();
extern void *dbase_main_task();
extern void *config_main_task();
extern void *su_main_task();

int main(int argc, char **argv)
{

	pid_t gps_pid = -1;
	pid_t wdog_pid = -1;
	pid_t remotem_pid = -1;
	pid_t ctrl_pid = -1;
	pid_t dbase_pid = -1;
	pid_t reader_pid = -1;
	pid_t config_pid = -1;
	pid_t su_pid = -1;

	if(argc > 1)
        {
	    if(!strcmp(argv[1], "-v"))
	    {
		printf("Run version: %s\n", RUN_VERSION);
	    }
	    return 0;
	}

	logging(DBG_DBG, "\n");
	logging(DBG_DBG, "\n");
	logging(DBG_DBG, "**********************************\n");
	logging(DBG_DBG, "       Application start ...\n");
	logging(DBG_DBG, "       Version: %s\n",RUN_VERSION );
	logging(DBG_DBG, "**********************************\n");
	
	// Start watch dog for log
	// Start config 
	if(config_pid == -1)
    {
        config_pid = fork();
        if(config_pid == 0) // child process
        {
            logging(DBG_DBG, "Launch config task ID: %i\n", getpid());
            prctl(PR_SET_NAME,"rfrain_config");
            config_main_task();
        }   
    }	

	logging(DBG_DBG," Sleep 5 second to make sure all services ready before task launch\n");
	sleep(5);
	if(wdog_pid == -1)
	{        
		wdog_pid = fork();
        if(wdog_pid == 0) // child process
        {
            logging(DBG_DBG, "Launch watchdog task ID: %i\n", getpid());
            prctl(PR_SET_NAME,"rfrain_watchdog");
            wdog_main_task();
        }
    }

	// Start reader 
	if(reader_pid == -1)
    {
        reader_pid = fork();
        if(reader_pid == 0) // child process
        {
            logging(DBG_DBG, "Launch reader task ID: %i\n", getpid());
            prctl(PR_SET_NAME,"rfrain_reader");
            reader_main_task();
        }   
    }	

	// Start gps 
	if(gps_pid == -1)
    {
        gps_pid = fork();
        if(gps_pid == 0) // child process
        {
            logging(DBG_DBG, "Launch gps task ID: %i\n", getpid());
            prctl(PR_SET_NAME,"rfrain_gps");
            gps_main_task();
        }   
    }	

	// Start remotem
	if(remotem_pid == -1)
    {
        remotem_pid = fork();
        if(remotem_pid == 0) // child process
        {
            logging(DBG_DBG, "Launch remotem task ID: %i\n", getpid());
            prctl(PR_SET_NAME,"rfrain_remotem");
            remotem_main_task();
        }   
    }	

	// Start controller 
	if(ctrl_pid == -1)
    {
        ctrl_pid = fork();
        if(ctrl_pid == 0) // child process
        {
            logging(DBG_DBG, "Launch controller task ID: %i\n", getpid());
            prctl(PR_SET_NAME,"rfrain_control");
            ctrl_main_task();
        }   
    }	

	// Start dbase 
	if(dbase_pid == -1)
    {
        dbase_pid = fork();
        if(dbase_pid == 0) // child process
        {
            logging(DBG_DBG, "Launch dbase task ID: %i\n", getpid());
            prctl(PR_SET_NAME,"rfrain_dbase");
            dbase_main_task();
        }   
    }	

	// Start software upgrade 
	if(su_pid == -1)
    {
        su_pid = fork();
        if(su_pid == 0) // child process
        {
            logging(DBG_DBG, "Launch software upgrade task ID: %i\n", getpid());
            prctl(PR_SET_NAME,"rfrain_su");
            su_main_task();
        }   
    }	

	while(1) {
		sleep(100); // Main task done after launch children processes
	}
}
