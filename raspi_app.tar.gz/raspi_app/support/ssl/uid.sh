#!/bin/sh
UNITCERT=./unit-cert.pem
if [ -f $UNITCERT ]; then 
	ID=`./deviceID $UNITCERT | sed 's/_//g' | sed 's/0//g'`
	echo rfr_$ID > /etc/hosts
fi 
