#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <stdio.h>
#include <openssl/rsa.h>       /* SSLeay stuff */
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/engine.h>


SSL_CTX		*sm_global_ctx=NULL;
#define MAX_CERT_SIZE 2048
#define DEVICE_ID_STRLEN 10

/* Default HW cryptodevice for the Flash project is the OCF cryptodev */
#define FLASH25_SM_HW_ENGINE	"cryptodev"
#define SM_CIPHER_STRING	"DES-CBC-SHA"
//#define SM_CIPHER_STRING	"RC4-MD5:DES-CBC3-SHA"


int main(int argc, char *argv[])
{
	char 			*str,*ptr;
	unsigned char	buf[MAX_CERT_SIZE];
	FILE 			*fp;
	X509 			*x509;
	int 			len;
	unsigned int	id=0xFFFFFFFF;
	static unsigned char 	deviceid[DEVICE_ID_STRLEN+1];

	ERR_load_crypto_strings();

	fp = fopen(argv[1], "r");
	if(fp == NULL)
	{
		printf("Error open certificate file\n");
		return 0;
	}

	x509 = PEM_read_X509(fp, NULL, NULL, NULL);

	fclose (fp);

	if (x509 == NULL)
	{
	  printf("error reading certificate\n");
	  return 0;
	}

	str = X509_NAME_oneline (X509_get_subject_name (x509), 0, 0);

	if (str)
	{
		ptr=strstr(str,"/CN=");

		if (ptr)
		{
			if (strlen(ptr)==4+DEVICE_ID_STRLEN)
			{
				strcpy(deviceid,ptr+4);
                //CR3825 Remove print line to clean up for REMOTEM API
				//printf("\t unit deviceid: %s\n",deviceid);
#ifdef NOTUSE
				if (memcmp(deviceid,"M_",2)==0)
				{
					sscanf(deviceid+2,"%x",&id);
				}
				 else printf("error parsing unit certificate - incorrect certificate type\n");
#endif
			}
			 else printf("error parsing unit certificate - invalid device id\n");
		}
		 else printf("error parsing unit certificate - can't find CN\n");

		OPENSSL_free (str);
	}
	 else printf("error parsing unit certificate - can't find subject\n");

	X509_free (x509);
	printf("%s\n", &deviceid[0]);
	return 1;
}

/*
 * vim:ft=c:fdm=marker:ff=unix:expandtab: tabstop=4: shiftwidth=4: autoindent: smartindent:
 */
