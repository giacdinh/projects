#!/bin/sh
openssl x509 -text < $1
