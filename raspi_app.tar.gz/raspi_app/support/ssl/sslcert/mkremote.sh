#!/bin/sh
openssl req -nodes -new -extensions v3_client -keyout remote-key.pem -out remote-req.pem -days 3650 -config ./factory.cnf
openssl ca -out remote-cert.pem -config ./factory.cnf -infiles remote-req.pem


