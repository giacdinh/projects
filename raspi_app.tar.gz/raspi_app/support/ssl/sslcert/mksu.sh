#!/bin/sh
openssl req -nodes -new -extensions v3_ca -keyout su-key.pem -out su-req.pem -days 3650 -config ./root.cnf
openssl ca -out su-cert.pem -config ./root.cnf -infiles su-req.pem
