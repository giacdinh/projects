#!/bin/sh
SERIAL=`tail -n 1 certindex.txt | awk -F "_" '{print toupper($2)}' | xargs echo "ibase=16; $1" | bc`
SERIAL=`expr $SERIAL + 1`
SNUM=`printf "%08x" $SERIAL`
SUBJECT=`echo /O=RFRain LLC/CN=M_$SNUM`
echo $SUBJECT

openssl req -nodes -new -keyout unit-key.pem -out unit-req.pem -days 3650 -config ./factory.cnf -subj "$SUBJECT"
openssl ca -batch -out unit-cert.pem -config ./factory.cnf -infiles unit-req.pem


