#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <openssl/rsa.h>       /* SSLeay stuff */
#include <openssl/crypto.h>
#include <openssl/x509.h>
#include <openssl/pem.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <openssl/engine.h>
#include <openssl/evp.h>

#define MEDIA_HASH_SIZE 2048

typedef struct
{
  SSL_CTX* ctx;
  SSL*     ssl;
  X509*    peer_cert;
  int      sd;
} _SM_HANDLE;
typedef _SM_HANDLE * SM_HANDLE;

typedef struct
{
        unsigned char data[MEDIA_HASH_SIZE];
} _SM_MEDIA_HASH;
typedef _SM_MEDIA_HASH * SM_MEDIA_HASH;

typedef struct
{
        EVP_MD_CTX md_ctx;
        EVP_PKEY *pkey;
        _SM_MEDIA_HASH hash;
        int hash_len;
} _SM_MEDIA_HANDLE;
typedef _SM_MEDIA_HANDLE * SM_MEDIA_HANDLE;

#define KEYF "/usr/local/bin/.unit-key.pem"
#define VALIDATE_FILE "/usr/local/bin/.validate"
#define SEED_FILE "/tmp/seed"
#define FIRST_BOOT "/usr/local/bin/.firstboot"

int error_handle(int);

SM_MEDIA_HANDLE GenerateHashOpen(void)
{
        SM_MEDIA_HANDLE h;

        h=(SM_MEDIA_HANDLE)malloc(sizeof(*h));

        if (h)
        {

          /* Just load the crypto library error strings,
           * SSL_load_error_strings() loads the crypto AND the SSL ones */
          /* SSL_load_error_strings();*/
            ERR_load_crypto_strings();

            FILE                  *fp;
            /* Read private key */

            fp = fopen (KEYF, "r");
            if (fp == NULL)
            {
               printf("error opening keyfile\n");
               free(h);
               return NULL;
            }

                  h->pkey = PEM_read_PrivateKey(fp, NULL, NULL, NULL);
                  fclose (fp);
          
	    if (h->pkey == NULL)
            {
              printf("error reading key\n");
              free(h);
              return NULL;
            }

            /* Do the signature */

            EVP_SignInit(&h->md_ctx, EVP_sha1());
        }

        return h;
}

int GenerateHashWrite(SM_MEDIA_HANDLE h, void *buffer, unsigned int buffer_len)
{
        int err;

        if (h == NULL)
        {
                return -1;
        }

        err=EVP_SignUpdate (&h->md_ctx, buffer, buffer_len);

        if (err != 1)
        {
                return -1;
        }

        return 0;
}

int GenerateHashClose(SM_MEDIA_HANDLE h, SM_MEDIA_HASH metadata, unsigned int *metadata_len)
{
        int err, ret=-1;

        if (h)
        {
                if (metadata==NULL)
                {
                        return -1;
                }

                if (metadata_len==NULL || ((*metadata_len) < sizeof(*metadata)) )
                {
                        printf(" *** Flash25AppSMGenerateHashClose:  error: hash buffer too small\n");
                        return -1;
                }

                err = EVP_SignFinal (&h->md_ctx, metadata->data, metadata_len, h->pkey);

                if (err == 1)
                {
                        ret=0;
                }
                else
                {
                    long err;
                    char erbuf[255];
                    while ( (err = ERR_get_error() ) != 0)
                    {
                        printf("---- Error: %ld - %s \n", err, ERR_error_string(err, erbuf));
                    }
                        printf(" *** Flash25AppSMGenerateHashClose:  error in EVP_SignFinal()\n");
                }

                if (h->pkey)
                {
                        EVP_PKEY_free (h->pkey);
                }

                free(h);
        }

        return ret;
}


int generate_hash(unsigned char *data, unsigned char *sig_buf, unsigned int *sig_len)
{
	int err;
	SM_MEDIA_HANDLE h;

	h=GenerateHashOpen();

	if (h==NULL)
	{
		printf("error in %s %d \n", __FUNCTION__, __LINE__);
		return -1;
	}

	err=GenerateHashWrite(h, data, strlen(data));

	if (err!=0)
	{
		printf("error in Flash25AppSMMediaHash()\n");
		return -1;
	}

	return GenerateHashClose(h,(SM_MEDIA_HASH) sig_buf, sig_len);

}

int main ()
{
	unsigned int sig_len;
	int err, i;
	unsigned char sig_buf [MEDIA_HASH_SIZE];
	static char data[128];

	memset(&data[0], '\0', 128);

	system("/usr/local/bin/.seed_518.sh");
	sleep(1);

	//check for first boot flag file
	if(access(FIRST_BOOT, 0) == 0) 
	{
		// flag file existed. Generate hash and return 0. No validate
		system("/usr/local/bin/.hashgen_518");
		system("rm /usr/local/bin/.firstboot");
		return 0;
	}

	// Open seed file to generate hash
	FILE *seedfp = fopen(SEED_FILE,"r");
	if(seedfp < 0)
	{
	    //printf("Error to open seed file\n");
	    return error_handle(1);
	}

	int rbyte;
	rbyte = fread(&data[0], 1, 128, seedfp);

	sig_len=sizeof(sig_buf);

	err=generate_hash(data,sig_buf, &sig_len);

	if (err!=0)
	{
	    return error_handle(2);
	}
	 else
	{
	    FILE *validate_file;
		validate_file = fopen(VALIDATE_FILE,"r");
		if(validate_file == NULL)
		{
			return error_handle(3);
		}
		unsigned char validate_buf[MEDIA_HASH_SIZE];
		int validate_sz;

		validate_sz = fread(&validate_buf[0], 1, sig_len, validate_file);
		if(validate_sz != sig_len)
		{
			return error_handle(4);
		}
		fclose(validate_file);

		for(i=0; i < sig_len; i++)
		{
			if(sig_buf[i] != validate_buf[i])
			{
				return error_handle(5);
			}
		}
	}

	return 0;
}

int error_handle(int debug)
{
	printf("Error taken place\n");
	switch(debug) {
		case 1:
			printf("open seed failed\n");
			break;
		case 2:
			printf("genhash failed\n");
			break;
		case 3:
			printf("open validate hash failed\n");
			break;
		case 4:
			printf("sign len didn't match\n");
			break;
		case 5:
			printf("validate compare failed\n");
			break;
		default:
			printf("Unknown error\n");
	}
	return -1;
}

