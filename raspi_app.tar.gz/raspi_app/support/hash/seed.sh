#!/bin/sh
cat /proc/cpuinfo |grep Serial | cut -c 11-30 > /tmp/seed
ifconfig wlan0 |grep ether | cut -c 15-31 >> /tmp/seed 
