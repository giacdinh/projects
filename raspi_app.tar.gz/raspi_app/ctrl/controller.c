#include <stdio.h>
#include <time.h>
#include <string.h>
#include <sys_msg.h>
#include <unistd.h>
#include <pthread.h>
#include <wiringPi.h>

#ifdef UNIT_DEBUG
#define DBG_CONTROL  1
#else
#define DBG_CONTROL  10
#endif

void *ctrl_dog_bark_task();
void ctrl_msg_handler(CTRL_MSG_T *Incoming);
void *ctrl_cmd_task();
int ctrl_send_reader_msg(int msg_id);
int gpioRead(int);
int gpioInit();

#define PIN21	21 	// This #21 is for WiringPi, RASPI pinout is GPIO #5 pin 27
			// Run "gpio readall" to know more in detail

void *ctrl_main_task()
{
	int result = -1;
	pthread_t ctrl_wd_id = -1, ctrl_cmd_id = -1;

    logging(DBG_INFO, "%s: Entering ...\n", __FUNCTION__);

    CTRL_MSG_T ctrl_msg;
	logging(DBG_INFO, "Create controller message\n");
	int msgid = create_msg(CTRL_MSGQ_KEY);
	
	if(msgid < 0)
	{
		logging(DBG_ERROR,"Failed to create controller message queue\n");
		return 0;
	}	

	/* Create thread for CTRL WD response */
	if(ctrl_wd_id == -1)
	{
		result = pthread_create(&ctrl_wd_id, NULL, ctrl_dog_bark_task, NULL);
        if(result == 0)
	        logging(DBG_DETAILED, "Starting controller dog bark thread.\n");
        else
            logging(DBG_ERROR, "CTRL WD thread launch failed\n");
	}

	/* Create thread for CTRL CMD */
	if(ctrl_cmd_id == -1)
	{
		result = pthread_create(&ctrl_cmd_id, NULL, ctrl_cmd_task, NULL);
        if(result == 0)
	        logging(DBG_DETAILED, "Starting controller cmd thread.\n");
        else
            logging(DBG_ERROR, "CTRL CMD thread launch failed\n");
	}

    (void) pthread_join(ctrl_wd_id, NULL);
    (void) pthread_join(ctrl_cmd_id, NULL);

	while(1) {
        recv_msg(msgid, (void *) &ctrl_msg, sizeof(CTRL_MSG_T), MSG_TIMEOUT);
        ctrl_msg_handler((CTRL_MSG_T *) &ctrl_msg);
        usleep(GENERIC_MSG_HANDLE_DELAY);
	}

	return (void *) 0;
}

void *ctrl_dog_bark_task()
{
    while(1) {
        send_dog_bark(CTRL_MODULE_ID);
        sleep(1);
    }
}

void *ctrl_cmd_task()
{
    int wiringPi_Pin21 = -1;
    static int trigger = -1;
    logging(DBG_INFO, "%s: Entering ...\n", __FUNCTION__);
     sleep(5);
    /* Init GPIO ports */
    if( 0 > wiringPiSetup())
	logging(DBG_ERROR,"Failed to init GPIO lib\n");

    while(1)
    {
	wiringPi_Pin21 = digitalRead(PIN21);
	if(wiringPi_Pin21 == 0)
	{
	    // Start scanning and put in database
	    logging(1, "Trigger press\n");
	    trigger = 1;
	    usleep(250000); /* to prevent trigger debounced */
	}
	else
	{
	    if(trigger == 1)
	    {
		//Trigger press then release, send trigger signal
	        logging(1, "Trigger release\n");
		ctrl_send_reader_msg(MSG_CTRL_HANDHELD_READ);
		trigger = 0;
	    }
	}
	usleep(250000); // Do monitor trigger every quarter of second
    }
}

void ctrl_msg_handler(CTRL_MSG_T *Incoming)
{
	CTRL_MSG_T *ctrl_msg;
    logging(DBG_INFO, "**** Incoming->modname: %s ****\n", modname[Incoming->header.moduleID]);
	
    switch(Incoming->header.subType)
    {
        default:
            logging(DBG_INFO, "%s: Unknown message type %d\n",__FUNCTION__, Incoming->header.subType);
            break;
    }
}

int ctrl_send_reader_msg(int msg_id)
{
    READER_MSG_T reader_msg;
    bzero((char *) &reader_msg, sizeof(READER_MSG_T));

    int msg_queue_id = open_msg(READER_MSGQ_KEY);
    if(msg_queue_id < 0)
    {
        logging(DBG_ERROR, "%s %d:Error invalid message queue\n",__FUNCTION__, __LINE__);
        return -1;
    }

    reader_msg.header.subType = msg_id;
    reader_msg.header.moduleID = CTRL_MODULE_ID;
    send_msg(msg_queue_id, (void *) &reader_msg, sizeof(READER_MSG_T), 3);

    return 0;
}


