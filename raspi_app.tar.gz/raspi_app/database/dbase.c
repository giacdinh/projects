#include <mysql/mysql.h>
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <sys_msg.h>
#include <unistd.h>
#include <pthread.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>

#ifdef UNIT_DEBUG
#define DBG_DBASE  1
#else
#define DBG_DBASE  10
#endif

int dbase_init(MYSQL *dbase);
int dbase_create_table(MYSQL *dbase, char *tablename);
int dbase_sys_curtime(char *);
int dbase_insert_tag(MYSQL *dbase, char *tablename, char *tag, int antid, int rssi, int epcLen);
//void dbase_msg_handler(DBASE_MSG_T *Incoming, MYSQL *dbase, char *tablename);
void dbase_msg_handler(DBASE_MSG_T *Incoming);
int dbase_check_table_exist(MYSQL *dbase, char *tablename);
void *dbase_dog_bark_task();
int dbase_check_existed_tag(char *tag, int *isExisted);
int put_dash_to_tag(char *source, char *dash_tag, int epcLen);
int dbase_remove_tag(MYSQL *dbase, char *tablename, char *tag);
int dbase_mobile_insert_tag(char *fulltag);
int dbase_mobile_update_tag(char *fulltag);
int dbase_check_existed_tag_master(char *tag, int *isExisted);
int dbase_mobile_insert_tag_master(char *fulltag);
int dbase_check_existed_tag_event(char *tag, int *isExisted);
int dbase_mobile_insert_tag_event(char *fulltag);
int dbase_mobile_update_tag_event(char *fulltag);

#define TABLE_NAME	"reader_rfraintest"
#define RFR_TABLE	"MainTable_m"

char *location = "defaults location";

void *dbase_main_task()
{
	MYSQL *dbase;
	int result = -1;
	pthread_t dbase_wd_id = -1;

    DBASE_MSG_T dbase_msg;
	logging(DBG_INFO, "Create data base message\n");
	int msgid = create_msg(DBASE_MSGQ_KEY);
	
	if(msgid < 0)
	{
		logging(DBG_ERROR,"Failed to create data base message queue\n");
		return 0;
	}	

	/* Create thread for DBASE WD response */
	if(dbase_wd_id == -1)
	{
		result = pthread_create(&dbase_wd_id, NULL, dbase_dog_bark_task, NULL);
        if(result == 0)
	        logging(DBG_DETAILED, "Starting data base dog bark thread.\n");
        else
            logging(DBG_ERROR, "DBASE WD thread launch failed\n");
	}

// single thread doesn't need  joined
//    (void) pthread_join(dbase_wd_id, NULL);
	while(1) {
        recv_msg(msgid, (void *) &dbase_msg, sizeof(DBASE_MSG_T), MSG_TIMEOUT);
        //dbase_msg_handler((DBASE_MSG_T *) &dbase_msg, dbase, TABLE_NAME);
        dbase_msg_handler((DBASE_MSG_T *) &dbase_msg);
        usleep(GENERIC_MSG_HANDLE_DELAY);
	}

	return (void *) 0;
}

void *dbase_dog_bark_task()
{
    while(1) {
        send_dog_bark(DBASE_MODULE_ID);
        sleep(1);
    }
}

MYSQL *dbase_mysql_open()
{
	MYSQL *conn;
	conn = mysql_init(NULL);
	if(conn == NULL)
	{
	    logging(DBG_ERROR, "%s--%d: Dbase init error\n", __FUNCTION__, __LINE__);
		return NULL;
	}
	if(mysql_real_connect(conn,"localhost","root","pierfrain2134!",NULL,0,NULL,0)== NULL)
	{
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(conn));
	    mysql_close(conn);
		return NULL;
	}

    if(mysql_query(conn, "use reader_control"))
    {
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(conn));
		return NULL;
    }

	return conn;
}

int dbase_mysql_close(MYSQL *conn)
{
	mysql_close(conn);
	return 1;	
}



//void dbase_msg_handler(DBASE_MSG_T *Incoming, MYSQL *dbase, char *tablename)
void dbase_msg_handler(DBASE_MSG_T *Incoming)
{
    int i, isExisted;
    char *headtag, *tailtag, *EPC, *pTag;
    int len, antid, rssi, freq;
    char tmpbuf[SHAREMEM_SZ];
	MYSQL *conn;

    logging(DBG_INFO, "**** Incoming->modname: %s ****\n", modname[Incoming->header.moduleID]);

    switch(Incoming->header.subType)
    {
	case MSG_TAG:
	break;

	case MSG_TAG_MOBILE_READ:
		headtag = (char *) Incoming->Tagpool;
	    char tmptag[64];
	    for(i=0 ; i < Incoming->tagcnt; i++)
	    {
			bzero(&tmptag[0],64);
			sscanf(headtag,"%[^\n]s",&tmptag[0]);
			headtag += strlen(&tmptag[0])+1; //Advance pointer to next tag

#ifndef USE_OLD_TABLE
			if(0 < dbase_check_existed_tag(&tmptag[0], &isExisted))
			{
				if(isExisted == 0)
				{
					logging(DBG_INFO, "%s %d: Tag not found insert to table\n", __FUNCTION__, __LINE__);
					dbase_mobile_insert_tag(&tmptag[0]); 
				}
				else
				{
					logging(DBG_INFO, "%s %d: Tag existed update access time\n", __FUNCTION__, __LINE__);
					dbase_mobile_update_tag(&tmptag[0]);
				}
			}
#else
			// Add additional code for new database usage structure
			if(0 < dbase_check_existed_tag_master(&tmptag[0], &isExisted))
			{
				if(isExisted == 0)
				{
					logging(DBG_INFO, "%s %d: Tag not found in Master table do insert\n", __FUNCTION__, __LINE__);
					dbase_mobile_insert_tag_master(&tmptag[0]); 
					dbase_mobile_insert_tag_event(&tmptag[0]);
				}
				else
				{
					if(0 < dbase_check_existed_tag_event(&tmptag[0], &isExisted))
					{
						if(isExisted == 0)
						{
							logging(DBG_INFO, "%s %d: Tag not found in Event table do insert\n", __FUNCTION__, __LINE__);
							dbase_mobile_insert_tag_event(&tmptag[0]);
						}
						else
						{
							logging(DBG_INFO, "%s %d: Tag existed update access time\n", __FUNCTION__, __LINE__);
							dbase_mobile_update_tag_event(&tmptag[0]);
						}
					}
				}
			}
#endif
	    }

	    break;
        default:
            logging(DBG_INFO, "%s: Unknown message type %d\n",__FUNCTION__, Incoming->header.subType);
            break;
    }
}

int dbase_check_existed_tag_master(char *tag, int *isExisted)
{
    MYSQL_RES *result;
	char querystr[256];
	int row;
	char ltag[32];
	char m_table[64];

	MYSQL *dbase = dbase_mysql_open();
	if(dbase == NULL)
	{
		logging(DBG_ERROR,"%s %d: Call failed\n");
		return -1;
	}
	
	sprintf(&m_table[0],"%s_m", RFR_TABLE);

	*isExisted = 0;
	
	sscanf(tag, "%s", &ltag[0]);

	sprintf((char *) &querystr, "select * from %s where tagnumb='%s'", &m_table[0], &ltag[0]);

	if(mysql_query(dbase, (char *) &querystr))
	{
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
	    return -1;
	}
	
	result = mysql_store_result(dbase);
    if(result == NULL)
    {
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
        return -1;
    }

	row = mysql_num_rows(result);

	if(row > 0)
	{
		*isExisted = 1;
	}
	
	mysql_free_result(result);
	dbase_mysql_close(dbase);
	return 1;
}

int dbase_check_existed_tag_event(char *tag, int *isExisted)
{
    MYSQL_RES *result;
	char querystr[256];
	int row;
	char ltag[32];
	char m_table[64];

	MYSQL *dbase = dbase_mysql_open();
	if(dbase == NULL)
	{
		logging(DBG_ERROR,"%s %d: Call failed\n");
		return -1;
	}
	
	sprintf(&m_table[0],"%s_e", RFR_TABLE);

	*isExisted = 0;
	
	sscanf(tag, "%s", &ltag[0]);

	sprintf((char *) &querystr, "select * from %s where tagnumb='%s'", &m_table[0], &ltag[0]);

	if(mysql_query(dbase, (char *) &querystr))
	{
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
	    return -1;
	}
	
	result = mysql_store_result(dbase);
    if(result == NULL)
    {
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
        return -1;
    }

	row = mysql_num_rows(result);

	if(row > 0)
	{
		*isExisted = 1;
	}
	
	mysql_free_result(result);
	dbase_mysql_close(dbase);
	return 1;
}

int dbase_check_existed_tag(char *tag, int *isExisted)
{
    MYSQL_RES *result;
	char querystr[256];
	int row;
	char ltag[32];

	MYSQL *dbase = dbase_mysql_open();
	if(dbase == NULL)
	{
		logging(DBG_ERROR,"%s %d: Call failed\n");
		return -1;
	}

	*isExisted = 0;
	
	sscanf(tag, "%s", &ltag[0]);

	sprintf((char *) &querystr, "select * from %s where epc='%s'", RFR_TABLE, &ltag[0]);

	if(mysql_query(dbase, (char *) &querystr))
	{
	    logging(DBG_ERROR, "%s--%d: Dbase query error %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
	    return -1;
	}
	
	result = mysql_store_result(dbase);
    if(result == NULL)
    {
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
        return -1;
    }

	row = mysql_num_rows(result);

	if(row > 0)
	{
#ifdef DEBUGPRINT
		MYSQL_ROW rows;
		int num_fields = mysql_num_fields(result);
  
		while ((rows = mysql_fetch_row(result))) 
		{ 
			for(int i = 0; i < num_fields; i++) 
				printf("%s ", rows[i] ? rows[i] : "NULL"); 
		}
#endif
		*isExisted = 1;
	}
	
	mysql_free_result(result);
	dbase_mysql_close(dbase);
	return 1;
}

int dbase_mobile_insert_tag_master(char *fulltag)
{
    char querystr[256];
    char tag[64];
	char m_table[64];

	MYSQL *dbase = dbase_mysql_open();
	if(dbase == NULL)
	{
		logging(DBG_ERROR,"%s %d: Call failed\n");
		return -1;
	}
	
	
	sprintf(&m_table[0],"%s_m", RFR_TABLE);

    if(sscanf(fulltag,"%s ", &tag[0]) != 1)
	{
		logging(DBG_ERROR,"%s %d: Invalid tag information string\n");
		return -1;
	} 
 
    sprintf((char *) &querystr,"INSERT INTO %s VALUES('NULL','NULL','NULL','NULL','NULL','NULL','%s')",
						&m_table[0], &tag[0]);
    if(mysql_query(dbase, querystr))
    {
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
		return -1; // RETURN DEFINE ERROR
    }
	dbase_mysql_close(dbase);
}

int dbase_mobile_insert_tag_event(char *fulltag)
{
    MYSQL_RES *result;
    char querystr[256];
	char m_table[64];
    char tag[64];
    char tagname[64];
	int antid, rssi, epcLen;

	MYSQL *dbase = dbase_mysql_open();
	if(dbase == NULL)
	{
		logging(DBG_ERROR,"%s %d: Call failed\n");
		return -1;
	}
	
    if(sscanf(fulltag,"%s %d %d %d ", &tag[0], &epcLen, &antid, &rssi) != 4) 
	{
		logging(DBG_ERROR,"%s %d: Invalid tag information string\n");
		return -1;
	} 
	sprintf(&m_table[0],"%s_e", RFR_TABLE);
	 
    if(sscanf(fulltag,"%s ", &tag[0]) != 1)
	{
		logging(DBG_ERROR,"%s %d: Invalid tag information string\n");
		return -1;
	} 
 
    sprintf((char *) &querystr,"INSERT INTO %s VALUES('NULL','NULL','NULL','NULL','NULL','NULL','%s','%s','%d','%d',UNIX_TIMESTAMP(),UNIX_TIMESTAMP())",
		&m_table[0], &tag[0],location,rssi,antid); 

    if(mysql_query(dbase, querystr))
    {
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
		return -1; // RETURN DEFINE ERROR
    }
	dbase_mysql_close(dbase);
}

int dbase_mobile_insert_tag(char *fulltag)
{
    char querystr[256];
    char tag[64];
    char tagname[64];
	int antid, rssi, epcLen;
	/* TODO hardcoded value */
	char unitid[]= "F_00000009"; 
	char location[]= "main_lab"; 

	MYSQL *dbase = dbase_mysql_open();
	if(dbase == NULL)
	{
		logging(DBG_ERROR,"%s %d: Call failed\n");
		return -1;
	}
   
    sscanf(fulltag,"%s %d %d %d ", &tag[0], &epcLen, &antid, &rssi); 

    if(0 == strncmp(&tag[0], "E2000016",8))	//Case of wrist band, only compare first 8
	strcpy(&tagname[0], "RDB wrist band");
    else if(0 == strncmp(&tag[0], "0000000000",10))
	strcpy(&tagname[0], "windshield");
    else if(0 == strncmp(&tag[0], "2017092712",10))
	strcpy(&tagname[0], "keychain");
    else if(0 == strncmp(&tag[0], "C9010AAAAA",10))
	strcpy(&tagname[0], "thick badge");
    else if(0 == strncmp(&tag[0], "35E0170205",10))
	strcpy(&tagname[0], "thin badge");
    else if(0 == strncmp(&tag[0], "E280116060",10))
	strcpy(&tagname[0], "paper #1");
    else if(0 == strncmp(&tag[0], "1500000000",10))
	strcpy(&tagname[0], "SATO wristband");
    else if(0 == strncmp(&tag[0], "0312470000",10))
	strcpy(&tagname[0], "BAP");
    else if(0 == strncmp(&tag[0], "2018020712",10))
	strcpy(&tagname[0], "Largest tag");
    else if(0 == strncmp(&tag[0], "3035307B28",10))
	strcpy(&tagname[0], "Clothes tag");
    else if(0 == strncmp(&tag[0], "E2001AC195",10))
	strcpy(&tagname[0], "paper #2");
    else if(0 == strncmp(&tag[0], "6000007879",10))
	strcpy(&tagname[0], "unknown #2");
    else
	strcpy(&tagname[0], "unknown");

    sprintf((char *) &querystr,"INSERT INTO %s VALUES('%s','%s', UNIX_TIMESTAMP(),'%s','%d','%d')",
						RFR_TABLE, &unitid[0], &location[0], &tag[0], rssi, antid);
    if(mysql_query(dbase, querystr))
    {
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
		return -1; // RETURN DEFINE ERROR
    }
	dbase_mysql_close(dbase);
}

int dbase_mobile_update_tag_event(char *fulltag)
{
    MYSQL_RES *result;
    char querystr[256];
    char tag[64];
	int antid, rssi, epcLen, row;
	char m_table[64]; 

	MYSQL *dbase = dbase_mysql_open();
	if(dbase == NULL)
	{
		logging(DBG_ERROR,"%s %d: Call failed\n");
		return -1;
	}
   
    if(sscanf(fulltag,"%s %d %d %d ", &tag[0], &epcLen, &antid, &rssi) != 4) 
	{
		logging(DBG_ERROR,"%s %d: Invalid tag information string\n");
		return -1;
	} 
	sprintf(&m_table[0],"%s_e", RFR_TABLE);

	// select access end time and compare to current system time to update or insert 
    sprintf((char *) &querystr,"select access_end,access_start from %s where tagnumb='%s' order by access_start desc limit 1", 
		&m_table[0], &tag[0]); 

	if(mysql_query(dbase, (char *) &querystr))
	{
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
	    return -1;
	}
	
	result = mysql_store_result(dbase);
    if(result == NULL)
    {
	    logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
        return -1;
    }

	row = mysql_num_rows(result);

	if(row > 0)
	{
		time_t t;
		t = time(0);
		char *ptr;
		long tag_time;
		MYSQL_ROW rows;
		rows = mysql_fetch_row(result);
		tag_time = strtol(rows[0], &ptr,10);
		
		//check the time different if system is 5s or larger, add another entry, other wise update fields
		if( (int) (t - tag_time) > 60)
		{
			//should call insert to event table
			dbase_mobile_insert_tag_event(fulltag);
		}
		else
		{
			sprintf((char *) &querystr,"UPDATE %s set access_end=UNIX_TIMESTAMP(),location='%s',ss='%d',antid='%d' where tagnumb='%s' and access_start='%s'", 
				&m_table[0], location, rssi, antid, &tag[0], rows[1]); 

			if(mysql_query(dbase, querystr))
			{
				logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
				dbase_mysql_close(dbase);
				return -1; // RETURN DEFINE ERROR
			}
		}
	}
	mysql_free_result(result);
	dbase_mysql_close(dbase);
	return 1;
}

int dbase_mobile_update_tag(char *fulltag)
{
    char querystr[256];
    char tag[64];
	MYSQL *dbase = dbase_mysql_open();
	if(dbase == NULL)
	{
		logging(DBG_ERROR,"%s %d: Call failed\n");
		return -1;
	}
   
    sscanf(fulltag,"%s", &tag[0]); 

    sprintf((char *) &querystr,"UPDATE %s set access=UNIX_TIMESTAMP() where epc='%s'", RFR_TABLE, &tag[0]); 

    if(mysql_query(dbase, querystr))
    {
		logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
		return -1; // RETURN DEFINE ERROR
    }
	dbase_mysql_close(dbase);
}


#ifdef NOTUSE
int dbase_insert_tag(MYSQL *dbase, char *tablename, char *tag, int antid, int rssi, int epcLen)
{
    char querystr[256];
    char timestring[64];

    dbase_sys_curtime((char *) &timestring);

    sprintf((char *) &querystr,"INSERT INTO %s VALUES('%s',NULL,'PRES',%d,%d,'%s')",
							tablename, tag,rssi,antid,&timestring);

    logging(DBG_DBG,"%s - %d: %s\n", __FILE__, __LINE__, &querystr);

    if(mysql_query(dbase, querystr))
    {
		logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
		return -1; // RETURN DEFINE ERROR
    }
}

int dbase_remove_tag(MYSQL *dbase, char *tablename, char *tag)
{
	char querystr[256];

	sprintf((char *) &querystr, "DELETE FROM %s WHERE tagnum='%s'", tablename, tag);
	
	if(mysql_query(dbase, querystr))
	{
		logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
		return -1; // RETURN DEFINE ERROR
	}
}

int dbase_sys_curtime(char *timestring)
{
    time_t t = time(NULL);
    struct tm *tm = localtime(&t);

    strftime(timestring, 64, "%Y-%m-%d %H:%M:%S", tm);

    return 0;
}

int dbase_check_table_exist(MYSQL *dbase, char *tablename)
{
	MYSQL_RES *result;
	char querystr[256];
	int row;

	sprintf((char *) &querystr, "show tables like \"%s\"; ", tablename);

	if(mysql_query(dbase, (char *) &querystr))
	{
		logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
		return -1;
	}
	
	result = mysql_store_result(dbase);
    if(result == NULL)
    {
		logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
        return -1;
    }

	row = mysql_num_rows(result);

	mysql_free_result(result);

	if(row > 0)
		return 1;
	
	return -1;
}

int dbase_create_table(MYSQL *dbase, char *tablename)
{
	char querystr[256];
	if(dbase == NULL || tablename == NULL)
	{
		logging(DBG_ERROR, "%s %d: Null pointer present\n", __FUNCTION__, __LINE__);
		return -1; // PROCESS_NULL_POINTER
	}

	sprintf((char *) &querystr, "CREATE TABLE %s(tagnum TEXT,tagname TEXT,detectstat TEXT,rssi INT,antid INT,access TEXT)",tablename);
    if(mysql_query(dbase, (char *) &querystr))
    {
		logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
        return -1;
    }
}

int dbase_missing_tag(MYSQL *dbase, MYSQL_RES *result, char *tablename, char *var1, char *var2)
{
	// Check pointer error
	char querystr[256];
	if(dbase == NULL || result == NULL || tablename == NULL || var1 == NULL || var2 == NULL)
	{
		logging(DBG_ERROR, "%s %d: Null pointer present\n", __FUNCTION__, __LINE__);
		return -1; // PROCESS_NULL_POINTER
	}
    sprintf(querystr,"SELECT %s,%s FROM %s WHERE detectstat='PRES' AND cmd='READ' AND execstat='NORM'",var1, var2,tablename);

	if(mysql_query(dbase, querystr))
	{
		logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
		return -1; // RETURN DEFINE ERROR
	}

	result = mysql_store_result(dbase);
	if(result == NULL)
	{
		logging(DBG_ERROR, "%s--%d: %s\n", __FUNCTION__, __LINE__, mysql_error(dbase));
		dbase_mysql_close(dbase);
		return -1;
	}
}

int put_dash_to_tag(char *source, char *dash_tag, int epcLen)
{
	int i;
	for(i = 0; i < epcLen*2; i++)
	{
		if(i%2 == 0 && i > 0)
			*dash_tag++ = '-';

		*dash_tag++ = *source++;
	}
	*dash_tag = '\0'; // End string
}
#endif // NOTUSE

