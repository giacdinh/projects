#include <stdio.h>
#include <time.h>
#include <string.h>
#include <sys_msg.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <string.h>
#include "rfr_config.h"

void *config_dog_bark_task();
void config_msg_handler(CONFIG_MSG_T *Incoming);
void *config_cmd_task();
//int config_send_reader_msg(int msg_id);
const char *process_json_data(char *ptr, char *search_key, int  *getint);
int config_init();
static int config_send_msg_to_reader(int config_msg_id, int value);

#ifdef UNIT_DEBUG
#define DBG_CONFIG	1
#else
#define DBG_CONFIG  10
#endif

void *config_main_task()
{
	int result = -1;
	pthread_t config_wd_id = -1, config_cmd_id = -1;
	CTRL_MSG_T config_msg;

    logging(DBG_INFO, "%s: Entering ...\n", __FUNCTION__);

	logging(DBG_INFO, "Create controller message\n");
	int msgid = create_msg(CONFIG_MSGQ_KEY);
	
	if(msgid < 0)
	{
		logging(DBG_ERROR,"Failed to create config message queue\n");
		return 0;
	}	

	/* Create thread for CONFIG WD response */
	if(config_wd_id == -1)
	{
		result = pthread_create(&config_wd_id, NULL, config_dog_bark_task, NULL);
        if(result == 0)
	        logging(DBG_DETAILED, "Starting config dog bark thread.\n");
        else
            logging(DBG_ERROR, "CONFIG WD thread launch failed\n");
	}

	/* Create thread for CONFIG CMD */
	if(config_cmd_id == -1)
	{
		result = pthread_create(&config_cmd_id, NULL, config_cmd_task, NULL);
        if(result == 0)
	        logging(DBG_DETAILED, "Starting config cmd thread.\n");
        else
            logging(DBG_ERROR, "CONFIG CMD thread launch failed\n");
	}

	logging(DBG_CONFIG,"%s %d: Config data init ...\n", __FUNCTION__, __LINE__);
	config_init();
    (void) pthread_join(config_wd_id, NULL);
    (void) pthread_join(config_cmd_id, NULL);

	while(1) {
        recv_msg(msgid, (void *) &config_msg, sizeof(CONFIG_MSG_T), MSG_TIMEOUT);
        config_msg_handler((CONFIG_MSG_T *) &config_msg);
        usleep(GENERIC_MSG_HANDLE_DELAY);
	}
	
	return (void *) 0;
}

void *config_dog_bark_task()
{
	// config start well ahead of most module bark need to wait
	sleep(7);
    while(1) {
        send_dog_bark(CONFIG_MODULE_ID);
        sleep(1);
    }
}

void *config_cmd_task()
{
    logging(DBG_INFO, "%s: Entering ...\n", __FUNCTION__);
    sleep(5);

    while(1)
    {
	
		usleep(250000); // Do monitor trigger every quarter of second
    }
}

void config_msg_handler(CONFIG_MSG_T *Incoming)
{
	CONFIG_MSG_T *config_msg;
    logging(DBG_INFO, "**** Incoming->modname: %s ****\n", modname[Incoming->header.moduleID]);
	
    switch(Incoming->header.subType)
    {
        default:
            logging(DBG_INFO, "%s: Unknown message type %d\n",__FUNCTION__, Incoming->header.subType);
            break;
    }
}

int config_init()
{
	int fp, rbyte, i;
	char confbuf[CONFIG_FILE_SZ];
	CONFIG_T config;

	logging(DBG_CONFIG,"%s %d: Entering ...\n", __FUNCTION__, __LINE__);
	
	fp = open(RFR_CONFIG_FILE, O_RDONLY);
	if(fp < 0)
	{
		logging(DBG_ERROR, "Open config.json failed\n");
		return -1;
	}

	rbyte = read(fp, &confbuf[0], CONFIG_FILE_SZ);

	if(rbyte > 0)
	{
		for(i=0; i < CONFIG_ENUM_UNKNOWN; i++)
		{
			if(i == END_OF_INT_FIELD)
				continue; // Skip this field

			switch(i) {
				case READ_SPEED:
					process_json_data((char *) &confbuf[0], CONFIG_FIELD[READ_SPEED], &(config.read_speed));
					logging(DBG_CONFIG, "read_speed: %d\n", config.read_speed);
					config_send_msg_to_reader(MSG_READER_RSPEED, config.read_speed);
					break;
				case READER_TIMEOUT:
					process_json_data((char *) &confbuf[0], CONFIG_FIELD[READER_TIMEOUT], &(config.reader_tout));
					logging(DBG_CONFIG, "reader_timeout: %d\n", config.reader_tout);
					config_send_msg_to_reader(MSG_READER_RTIMEOUT, config.reader_tout);
					break;
				case READER_POWER:
					process_json_data((char *) &confbuf[0], CONFIG_FIELD[READER_POWER], &(config.reader_power));
					logging(DBG_CONFIG, "reader_power: %d\n", config.reader_power);
					config_send_msg_to_reader(MSG_READER_POWER, config.reader_power);
					break;
				case READER_TZONE:
					process_json_data((char *) &confbuf[0], CONFIG_FIELD[READER_TZONE], &(config.reader_tzone));
					logging(DBG_CONFIG, "reader_tzone: %d\n", config.reader_tzone);
					break;
				case READER_ZONE:
					process_json_data((char *) &confbuf[0], CONFIG_FIELD[READER_ZONE], &(config.reader_zone));
					logging(DBG_CONFIG, "reader_zone: %d\n", config.reader_zone);
					break;
				case READER_MODE:
					process_json_data((char *) &confbuf[0], CONFIG_FIELD[READER_MODE], &(config.reader_mode));
					logging(DBG_CONFIG, "reader_mode: %d\n", config.reader_mode);
					break;
				case READER_PORT:
					process_json_data((char *) &confbuf[0], CONFIG_FIELD[READER_PORT], &(config.reader_port));
					logging(DBG_CONFIG, "reader_port: %d\n", config.reader_port);
					break;
				// End of integer value fields
				case READER_TYPE:
					strncpy(config.reader_type, process_json_data((char *) &confbuf[0], CONFIG_FIELD[READER_TYPE], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "reader_type: %s\n", config.reader_type);
					break;
				case READER_LOCATION:
					strncpy(config.location, process_json_data((char *) &confbuf[0], CONFIG_FIELD[READER_LOCATION], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "location: %s\n", config.location);
					break;
				case ANT_1:
					strncpy(config.ant_1, process_json_data((char *) &confbuf[0], CONFIG_FIELD[ANT_1], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "ant_1: %s\n", config.ant_1);
					break;
				case ANT_2:
					strncpy(config.ant_2, process_json_data((char *) &confbuf[0], CONFIG_FIELD[ANT_2], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "ant_2: %s\n", config.ant_2);
					break;
				case ANT_3:
					strncpy(config.ant_3, process_json_data((char *) &confbuf[0], CONFIG_FIELD[ANT_3], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "ant_3: %s\n", config.ant_3);
					break;
				case ANT_4:
					strncpy(config.ant_4, process_json_data((char *) &confbuf[0], CONFIG_FIELD[ANT_4], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "ant_4: %s\n", config.ant_4);
					break;
				case ANT_5:
					strncpy(config.ant_5, process_json_data((char *) &confbuf[0], CONFIG_FIELD[ANT_5], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "ant_5: %s\n", config.ant_5);
					break;
				case ANT_6:
					strncpy(config.ant_6, process_json_data((char *) &confbuf[0], CONFIG_FIELD[ANT_6], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "ant_6: %s\n", config.ant_6);
					break;
				case ANT_7:
					strncpy(config.ant_7, process_json_data((char *) &confbuf[0], CONFIG_FIELD[ANT_7], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "ant_7: %s\n", config.ant_7);
					break;
				case ANT_8:
					strncpy(config.ant_8, process_json_data((char *) &confbuf[0], CONFIG_FIELD[ANT_8], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "ant_8: %s\n", config.ant_8);
					break;
				case USER_NAME:
					strncpy(config.user, process_json_data((char *) &confbuf[0], CONFIG_FIELD[USER_NAME], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "user: %s\n", config.user);
					break;
				case PASS_WD:
					strncpy(config.pass, process_json_data((char *) &confbuf[0], CONFIG_FIELD[PASS_WD], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "pass: %s\n", config.pass);
					break;
				case DBASE_NAME:
					strncpy(config.dbase, process_json_data((char *) &confbuf[0], CONFIG_FIELD[DBASE_NAME], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "dbase: %s\n", config.dbase);
					break;
				case TABLE_NAME:
					strncpy(config.table, process_json_data((char *) &confbuf[0], CONFIG_FIELD[TABLE_NAME], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "table: %s\n", config.table);
					break;
				case GPS:
					strncpy(config.gps, process_json_data((char *) &confbuf[0], CONFIG_FIELD[GPS], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "GPS: %s\n", config.gps);
					break;
				case CAMERA:
					strncpy(config.camera, process_json_data((char *) &confbuf[0], CONFIG_FIELD[CAMERA], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "camera: %s\n", config.camera);
					break;
				case SCALE:
					strncpy(config.scale, process_json_data((char *) &confbuf[0], CONFIG_FIELD[SCALE], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "scale: %s\n", config.scale);
					break;
				case SSID1:
					strncpy(config.ssid1, process_json_data((char *) &confbuf[0], CONFIG_FIELD[SSID1], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "ssid1: %s\n", config.ssid1);
					break;
				case PASSWD1:
					strncpy(config.passwd1, process_json_data((char *) &confbuf[0], CONFIG_FIELD[SSID1], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "passwd1: %s\n", config.passwd1);
					break;
				case SSID2:
					strncpy(config.ssid2, process_json_data((char *) &confbuf[0], CONFIG_FIELD[SSID2], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "ssid2: %s\n", config.ssid2);
					break;
				case PASSWD2:
					strncpy(config.passwd2, process_json_data((char *) &confbuf[0], CONFIG_FIELD[SSID2], 0),MAX_CONFIG_SZ);
					logging(DBG_CONFIG, "passwd2: %s\n", config.passwd2);
					break;
					
				default:
					logging(DBG_ERROR, "CONFIG FIELDs loading ID invalid: %d\n", i);
					break;
			}

		}
	}	
	else
		logging(DBG_ERROR,"Attempt to read config file failed\n");

}

static int config_send_msg_to_reader(int remote_msg_id, int value)
{
    READER_MSG_T reader_msg;
    bzero((char *) &reader_msg, sizeof(READER_MSG_T));

    int msg_queue_id = open_msg(READER_MSGQ_KEY);
    if(msg_queue_id < 0)
    {
        logging(DBG_ERROR, "%s %d:Error invalid message queue\n",__FUNCTION__, __LINE__);
        return -1;
    }

    reader_msg.header.subType = remote_msg_id;
    reader_msg.header.moduleID = CONFIG_MODULE_ID;
    reader_msg.value = value;
    send_msg(msg_queue_id, (void *) &reader_msg, sizeof(READER_MSG_T), 3);

    return 0;
}


/*
int config_send_reader_msg(int msg_id)
{
    READER_MSG_T reader_msg;
    bzero((char *) &reader_msg, sizeof(READER_MSG_T));

    int msgid = open_msg(READER_MSGQ_KEY);
    if(msgid < 0)
    {
        logging(DBG_ERROR, "Error invalid message queue\n");
        return -1;
    }

    reader_msg.header.subType = MSG_MOBILE_SCAN_TAG;
    reader_msg.header.moduleID = CONFIG_MODULE_ID;
    send_msg(msgid, (void *) &reader_msg, sizeof(READER_MSG_T), 3);

    return 0;
}
*/


