#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <sys_msg.h>
#include <unistd.h>
#include <pthread.h>
#include <signal.h>
#include <errno.h>
#include <assert.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <arpa/inet.h>

#include "remotem.h"
#include <sys_msg.h>

#define REMOTEM_LOCAL_IPADDR    "127.0.0.1"
static struct sockaddr_in gWebServerAddr;
#define WEB_SERVER_PORT         (81)
#define REMOTEM_PROXY_PORT      (5010)
#define REMOTEM_WAIT_PORT_AVAILABLE (60)  //seconds
#define REMOTEM_BACKLOG         (10)
#define REQUEST_MAX				(256)

#ifdef UNIT_DEBUG
#define DBG_REMOTEM  1
#else
#define DBG_REMOTEM  10
#endif

void remotem_msg_handler(REMOTEM_MSG_T *Incoming);
void *remotem_dog_bark_task();
void *remotem_com_task();
void REMOTEMActionSIGCHLD(int sigNum, siginfo_t *pInfo, void *unused);
int remotem_worker_process();
int remotem_tag_read();
int remotem_request_handler(int);
static int remotem_send_msg_to_reader(int msg_id, int value);
int remotem_socket_create(void);
void request_response_header(int new_remotem_sock);
int remotem_set_antenna( );
int get_config_value(char *request, char *token);
char *unit_ID();
int broadcast_id(char *);
char *get_config_str(char *request, char *token);
static int remotem_send_msg_to_su(int su_msg_id, char *filename);
static inline char *parse_arg(char *arg);

void *remotem_main_task()
{
    REMOTEM_MSG_T remotem_msg;
	pthread_t remotem_dog_id = -1, remotem_com_id = -1;
	int result = -1;
	logging(DBG_INFO, "%s: Entering ...\n", __FUNCTION__);

    int msgid = create_msg(REMOTEM_MSGQ_KEY);

    if(msgid < 0)
    {
        logging(DBG_ERROR, "%s %d:Failed to create remotem message queue\n",__FUNCTION__, __LINE__ );
        return 0;
    }

	/* Create thread for watchdog response */
	if(remotem_dog_id == -1)
	{
		result = pthread_create(&remotem_dog_id, NULL, remotem_dog_bark_task, NULL);
		if(result == 0)
			logging(DBG_INFO, "Starting remotem dog bark thread.\n");
		else
			logging(DBG_ERROR, "REMOTEM WD response thread launch failed\n");
	}
	
	/* Create connection handler */
	if(remotem_com_id == -1)
	{
		result = pthread_create(&remotem_com_id, NULL, remotem_com_task, NULL);
		if(result == 0)
			logging(DBG_INFO, "Starting remotem com thread.\n");
		else
			logging(DBG_ERROR, "REMOTEM COM thread launch failed\n");
	}

	/* join both thread before run */
	
    (void) pthread_join(remotem_dog_id, NULL);
    (void) pthread_join(remotem_com_id, NULL);

	while(1) {
		logging(DBG_INFO, " REMOTEM Main task loop\n");
        recv_msg(msgid, (void *) &remotem_msg, sizeof(REMOTEM_MSG_T), MSG_TIMEOUT);
        remotem_msg_handler((REMOTEM_MSG_T *) &remotem_msg);
        usleep(GENERIC_MSG_HANDLE_DELAY); //Should be lesser sleep
	}
	return (void *) 0;
}

void remotem_msg_handler(REMOTEM_MSG_T *Incoming)
{
    logging(DBG_INFO, "**** Incoming->modname: %s ****\n", modname[Incoming->header.moduleID]);
    switch(Incoming->header.subType)
    {
        default:
            logging(DBG_INFO, "%s: Unknown message type %d\n",__FUNCTION__, Incoming->header.subType);
            break;
    }
}

void *remotem_dog_bark_task()
{
	static int broadcast_cnt = 0;
	char *unit_id;
	unit_id = unit_ID();

    while(1) 
	{
        send_dog_bark(REMOTEM_MODULE_ID);
        sleep(1);
		broadcast_cnt++;
		if(broadcast_cnt > 5)
		{
			broadcast_cnt = 0;
			broadcast_id(unit_id);
		}
    }
	return (void *) 0;
}

void *remotem_com_task()
{
    struct sockaddr_in remotem_socket_addr;
    int remotem_socketId = -1, new_remotem_sock = -1;
    int sockaddr_size;

    remotem_socketId = remotem_socket_create();
    if(remotem_socketId < 0)
    {
        logging(DBG_ERROR, "%s %d: Failed to create socket \n", __FUNCTION__, __LINE__);
    }

    if((listen(remotem_socketId, REMOTEM_BACKLOG)) < 0)
    {
        if (errno != EINTR)
        {
            logging(DBG_ERROR, "%s %d: Socket: %d failed to listen\n", __FUNCTION__, __LINE__, remotem_socketId);
            close(remotem_socketId);
            exit(0);
        }
    }
    logging(DBG_INFO, "%s %d: Socket: %d listened\n", __FUNCTION__, __LINE__, remotem_socketId);

    if((listen(remotem_socketId, REMOTEM_BACKLOG)) < 0)
    {
        if (errno != EINTR)
        {
            logging(DBG_ERROR, "%s %d: Socket: %d failed to listen\n", __FUNCTION__, __LINE__, remotem_socketId);
            close(remotem_socketId);
            exit(0);
        }
    }
    logging(DBG_INFO, "%s %d: Socket: %d listened\n", __FUNCTION__, __LINE__, remotem_socketId);

    /* Accepting socket */
    sockaddr_size = sizeof(struct sockaddr_in);
    memset(&remotem_socket_addr, 0, sockaddr_size);

    while (new_remotem_sock = accept(remotem_socketId,(struct sockaddr *) &remotem_socket_addr, &sockaddr_size))
	{
		remotem_request_handler(new_remotem_sock);
	}
	return (void *) 0;
}

int remotem_socket_create(void)
{
    struct sockaddr_in REMOTEMSocketAddr;
    int bindTmout = REMOTEM_WAIT_PORT_AVAILABLE;
    int sock = -1; 
    int rc = -1;
    struct linger lng;
    int reuseAddr = 1;

	logging(DBG_INFO, "%s %d: Entering ...\n", __FUNCTION__, __LINE__);
    /* Create a Socket using the Security Manager API .*/
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (-1 == sock)
    {
		logging(DBG_ERROR, "%s %d: Failed to create socket\n", __FUNCTION__, __LINE__);
        return -1;
    }
    memset(&REMOTEMSocketAddr, 0, sizeof(REMOTEMSocketAddr));
    REMOTEMSocketAddr.sin_family = AF_INET;
    REMOTEMSocketAddr.sin_port = htons(RFR_REMOTEM_PORT);
    REMOTEMSocketAddr.sin_addr.s_addr = htonl(INADDR_ANY);

    lng.l_onoff  = 0;
    lng.l_linger = 1;

    setsockopt(sock, SOL_SOCKET,SO_LINGER, (const void *)&lng, sizeof(lng));
    setsockopt(sock, SOL_SOCKET,SO_REUSEADDR, (const void *)&reuseAddr, sizeof(reuseAddr));

    while (bindTmout > 0)
    {
        if ((rc = bind(sock, (struct sockaddr *) &REMOTEMSocketAddr, sizeof(REMOTEMSocketAddr))) >= 0)
        {
            bindTmout = 0;
        }
        else
        {
	    logging(DBG_ERROR, "%s %d: bin() Failed err=%s(%d)\n", 
		__FUNCTION__, __LINE__, strerror(errno), errno);
            bindTmout--;
        }
    }

    if (rc < 0)
    {
	logging(DBG_ERROR, "%s %d: bin() Failed err=%s(%d)\n", 
		__FUNCTION__, __LINE__, strerror(errno), errno);
        return -1;
    }

	logging(DBG_INFO, "%s %d: Socket: %d created\n", __FUNCTION__, __LINE__, sock);
    return sock;
}

//char parse_work_space[64];
char request_buffer[512];


int remotem_request_handler(int new_remotem_sock)
{
	//char income_request[REQUEST_MAX];
	int read_byte;
	
	//Clean out request work_buffer before use
	bzero((char *) &request_buffer, 512);

	read_byte = read(new_remotem_sock, &request_buffer, REQUEST_MAX);
	logging(DBG_DETAILED, "Request: %s\n", &request_buffer);

	request_response_header(new_remotem_sock);

	// Read tag cmd
	if(NULL != strstr((char *) &request_buffer, REMOTEM_TAG_READ))
	{
	    logging(DBG_DETAILED,"read tag single\n");
	    remotem_send_msg_to_reader(MSG_REMOTEM_TAG_READ, 0);
	}
	else if(NULL != strstr((char *) &request_buffer, REMOTEM_REPEAT_READ))
	{
	    logging(DBG_DBG,"repeat start\n");
		// Creat repeat read flag
		system("echo 1 > /tmp/repeat_read");
	    remotem_send_msg_to_reader(MSG_REMOTEM_REPEAT_READ, 0);
	}
	else if(NULL != strstr((char *) &request_buffer, REMOTEM_REPEAT_STOP))
	{
	    logging(DBG_DBG,"repeat stop\n");
		// remove repeat read flag
		system("rm -f /tmp/repeat_read");
	}
	else if(NULL != strstr((char *) &request_buffer, REMOTEM_HANDHELD_READ))
	{
	    logging(DBG_DBG,"%s %d: Handheld read\n", __FUNCTION__, __LINE__);
	    remotem_send_msg_to_reader(MSG_REMOTEM_HANDHELD_READ, 0);
	}
	else if(NULL != strstr((char *) &request_buffer, REMOTEM_SET_POWER))
	{
		int power;
		power = get_config_value((char *) &request_buffer, "power=");
	    logging(DBG_DBG,"set power: %d\n", power);
	    remotem_send_msg_to_reader(MSG_REMOTEM_CONFIG_SET_POWER, power);
	}
	else if(NULL != strstr((char *) &request_buffer, REMOTEM_SET_REGION))
	{
		int region;
		region = get_config_value((char *) &request_buffer, "region=");
	    logging(DBG_DBG,"set region: %d\n", region);
	    remotem_send_msg_to_reader(MSG_REMOTEM_CONFIG_SET_REGION, region);
	}
	else if(NULL != strstr((char *) &request_buffer, REMOTEM_SYS_SHUTDOWN))
	{
	    logging(DBG_DBG,"System shutdown\n");
	    system("sudo shutdown -h now");
	}
	else if(NULL != strstr((char *) &request_buffer, REMOTEM_SYS_REBOOT))
	{
	    logging(DBG_DBG,"System reboot\n");
	    system("sudo reboot");
	}
	else if(NULL != strstr((char *) &request_buffer, REMOTEM_SYS_CLKSYNC))
	{
    	    logging(DBG_DBG,"System clock sync\n");
	    int times;
	    char date_cmd[128];
    	    times = get_config_value((char *) &request_buffer, "date=");

    	    sprintf(&date_cmd[0], "sudo date -s '@%d'", times);
    	    system(&date_cmd[0]);
	}
	else if(NULL != strstr((char *) &request_buffer, REMOTEM_GET_UID))
	{
	    logging(DBG_DBG,"Get unit ID\n");
		/*send response back with unit ID information */
		write(new_remotem_sock, GENERAL_RESPONSE_HEADER, strlen(GENERAL_RESPONSE_HEADER));
		write(new_remotem_sock, unit_ID(), 10);
	}
	else if(NULL != strstr((char *) &request_buffer, REMOTEM_SU_START))
	{
		char *fname = parse_arg("filename=");
	    logging(DBG_REMOTEM,"SU start with %s\n", fname);
		/*send response back with unit ID information */
		write(new_remotem_sock, GENERAL_RESPONSE_HEADER, strlen(GENERAL_RESPONSE_HEADER));
		remotem_send_msg_to_su(MSG_SU_START, fname);
	}


	close(new_remotem_sock);
	return 0;
}

int get_config_value(char *request, char *token)
{
	char *tem;
	int ret;
	tem = strstr(request,token);

	tem += strlen(token);
	ret = atoi(tem);

	return ret;	
}

char *get_config_str(char *request, char *token)
{
	char *tem;
	tem = strstr(request,token);

	tem += strlen(token);
	return tem;	
}

static inline char *parse_arg(char *arg)
{
    char *temp;
    int j;
	static char key[32];
//    memset(&parse_work_space, '\0', 512);

    temp = strstr((char *)&request_buffer, arg);
    if(temp == NULL)
		return NULL;

    for(j=0; j < 512; j++)
    {
        if(*temp == '&' || *temp == 0x20 || *temp == '\0')
        {
            key[j] = '\0';
            break;
        }
        key[j] = *temp++;
    }
	temp = &key[0];
	temp += strlen(arg);

    return temp;
}
	
void request_response_header(int new_remotem_sock)
{
	write(new_remotem_sock, GENERAL_RESPONSE_HEADER, strlen(GENERAL_RESPONSE_HEADER));
}

static int remotem_send_msg_to_reader(int remote_msg_id, int value)
{
    READER_MSG_T reader_msg;
    bzero((char *) &reader_msg, sizeof(READER_MSG_T));
 
    int msg_queue_id = open_msg(READER_MSGQ_KEY);
    if(msg_queue_id < 0)
    {
	logging(DBG_ERROR, "%s %d:Error invalid message queue\n",__FUNCTION__, __LINE__);
        return -1;
    }

    reader_msg.header.subType = remote_msg_id;
    reader_msg.header.moduleID = REMOTEM_MODULE_ID;
    reader_msg.value = value;
    send_msg(msg_queue_id, (void *) &reader_msg, sizeof(READER_MSG_T), 3);

    return 0;
}

static int remotem_send_msg_to_su(int su_msg_id, char *filename)
{
    SU_MSG_T su_msg;
    bzero((char *) &su_msg, sizeof(SU_MSG_T));
 
    int msg_queue_id = open_msg(SU_MSGQ_KEY);
    if(msg_queue_id < 0)
    {
	logging(DBG_ERROR, "%s %d:Error invalid message queue\n",__FUNCTION__, __LINE__);
        return -1;
    }

    su_msg.header.subType = su_msg_id;
    su_msg.header.moduleID = REMOTEM_MODULE_ID;
	strncpy(su_msg.filename,filename,128);

    send_msg(msg_queue_id, (void *) &su_msg, sizeof(SU_MSG_T), 3);
    return 0;
}

