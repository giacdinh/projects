#!/bin/bash
wget -q http://$1:9999/remotem_sys_clksync.cgi?date=1548712255
