#!/bin/sh
wget -q http://192.168.1.127:9999/remotem_tag_read.cgi
