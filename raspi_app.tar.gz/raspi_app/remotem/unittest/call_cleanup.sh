#!/bin/sh
rm *cgi*
