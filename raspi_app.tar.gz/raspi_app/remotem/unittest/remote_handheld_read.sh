#!/bin/bash
wget -q http://$1:9999/remotem_handheld_read.cgi
