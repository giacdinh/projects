#!/bin/bash
wget -q http://$1:9999/remotem_set_power.cgi?power=2200
