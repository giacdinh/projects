#include <stdio.h>
#include <time.h>
#include <string.h>
#include <sys_msg.h>
#include <unistd.h>
#include <pthread.h>

void *gps_dog_bark_task();
void gps_msg_handler(CTRL_MSG_T *Incoming);
void *gps_cmd_task();
int gps_main();

void *gps_main_task()
{
	int result = -1;
	pthread_t gps_wd_id = -1, gps_cmd_id = -1;

    logging(DBG_INFO, "%s: Entering ...\n", __FUNCTION__);

    CTRL_MSG_T gps_msg;
	logging(DBG_INFO, "Create controller message\n");
	int msgid = create_msg(CTRL_MSGQ_KEY);
	
	if(msgid < 0)
	{
		logging(DBG_ERROR,"Failed to create controller message queue\n");
		return 0;
	}	

	/* Create thread for CTRL WD response */
	if(gps_wd_id == -1)
	{
		result = pthread_create(&gps_wd_id, NULL, gps_dog_bark_task, NULL);
        if(result == 0)
	        logging(DBG_DETAILED, "Starting controller dog bark thread.\n");
        else
            logging(DBG_ERROR, "CTRL WD thread launch failed\n");
	}

	/* Create thread for CTRL CMD */
	if(gps_cmd_id == -1)
	{
		result = pthread_create(&gps_cmd_id, NULL, gps_cmd_task, NULL);
        if(result == 0)
	        logging(DBG_DETAILED, "Starting controller cmd thread.\n");
        else
            logging(DBG_ERROR, "CTRL CMD thread launch failed\n");
	}

    (void) pthread_join(gps_wd_id, NULL);
    (void) pthread_join(gps_cmd_id, NULL);

	while(1) {
        recv_msg(msgid, (void *) &gps_msg, sizeof(CTRL_MSG_T), MSG_TIMEOUT);
        gps_msg_handler((CTRL_MSG_T *) &gps_msg);
        usleep(GENERIC_MSG_HANDLE_DELAY);
	}

	return (void *) 0;
}

void *gps_dog_bark_task()
{
    while(1) {
        send_dog_bark(GPS_MODULE_ID);
        sleep(1);
    }
}

void *gps_cmd_task()
{
    logging(DBG_INFO, "%s: Entering ...\n", __FUNCTION__);
	sleep(5);
	gps_main();
	while(1)
	{
		sleep(1);
	}
}

void gps_msg_handler(CTRL_MSG_T *Incoming)
{
	CTRL_MSG_T *gps_msg;
    logging(DBG_INFO, "**** Incoming->modname: %s ****\n", modname[Incoming->header.moduleID]);
	
    switch(Incoming->header.subType)
    {
        default:
            logging(DBG_INFO, "%s: Unknown message type %d\n",__FUNCTION__, Incoming->header.subType);
            break;
    }
}

