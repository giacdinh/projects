#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h> 
#include <termios.h>
#include <unistd.h>
#include <sys_msg.h>

#define GPS_SERIAL_DEV "/dev/ttyUSB0"

#ifdef UNIT_DEBUG
#define DBG_GPS  1
#else
#define DBG_GPS  10
#endif

extern int store_gps_GGA(char *);
extern int store_gps_RMC(char *);
extern int store_gps_RMC(char *);

int gps_set_serial(int fd, int speed)
{
    struct termios tty;

    if (tcgetattr(fd, &tty) < 0) {
        printf("Error from tcgetattr: %s\n", strerror(errno));
        return -1;
    }

    cfsetospeed(&tty, (speed_t)speed);
    cfsetispeed(&tty, (speed_t)speed);

    tty.c_cflag |= (CLOCAL | CREAD);    /* ignore modem controls */
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;         /* 8-bit characters */
    tty.c_cflag &= ~PARENB;     /* no parity bit */
    tty.c_cflag &= ~CSTOPB;     /* only need 1 stop bit */
    tty.c_cflag &= ~CRTSCTS;    /* no hardware flowcontrol */

    /* setup for non-canonical mode */
    tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    tty.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
    tty.c_oflag &= ~OPOST;

    /* fetch bytes as they become available */
    tty.c_cc[VMIN] = 1;
    tty.c_cc[VTIME] = 1;

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        printf("Error from tcsetattr: %s\n", strerror(errno));
        return -1;
    }
    return 0;
}

int gps_main()
{
	int fd, i;
	char read_buf[1024];
	int readbyte;
	char *src,*dest;
	char GPGGA[128];
	fd = open(GPS_SERIAL_DEV, O_RDWR);
	if( fd < 0)
	{
		logging(DBG_ERROR, "GPS device is not ready\n");
		return -1;
	}

	gps_set_serial(fd, B4800);

	/* Init read single NMEA string */
	char single_sentence[128], *temp;
	temp = (char *) &single_sentence;
	bzero(temp,128);

	while(1)
	{
		read(fd,temp,1);
		if(*temp == '\n')
		{
			//printf("%s", (char *) &single_sentence);	
			/* Pass to process to each sentence format */
			// Coordination
#ifdef GPS_GET_COORDINATION
			if(temp = strstr((char *) &single_sentence, "$GPGGA"))
			{
				store_gps_GGA((char *) &single_sentence);
			}
#endif
			// Speed and coordination
			if(temp = strstr((char *) &single_sentence, "$GPRMC"))
			{
				store_gps_RMC((char *) &single_sentence);
			}
			
			/* reset space for the next sentence */
			temp = (char *) &single_sentence;
			bzero(temp,128);
			usleep(5000); // Sleep 5 mils 
		}
		else
			temp++;
	}
}


