#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <time.h>
#ifdef UNITTEST
#else
#include <sys_msg.h>
#endif

typedef struct {
	char gpstype[16];
	char gpstime[16];
	char gpslat[16];
    char gpslatpos[4];
	char gpslong[16];
    char gpslongpos[4];
	char gpsfix[4]; //0=invalid,1=GPS,2=DGPS,3=PPS,4=RTK,5=float,6=estimated
	char gpssat[4]; //number of satellite
	char gpshoz[8];
	char gpsalt[16];
	char gpsaltM[4];
} NMEA_GGA_T;

typedef struct {
	char gpstype[16];
	char gpstime[16];
	char gpswarn[4];  // A=OK, V=warning
	char gpslat[16];
    char gpslatpos[4];
	char gpslong[16];
    char gpslongpos[4];
	char gpsspeed[16];
	char gpscourse[16];
	char gpsdate[16];
} NMEA_RMC_T;

int store_gps_GGA(char *gpsGGA)
{
	char logbuf[128];
    char datafiletime[64];
    char datafilename[64];
    char timebuf[32];
	struct tm ts;
	int satfix = -1;
	int satnum = -1;

	time_t now = time(NULL);

    sprintf((char *) &datafilename[0], "/tmp/rfrain_gps.txt");

	int fd;
    fd = open( (char *) &datafilename , O_RDWR | O_APPEND | O_CREAT, 0666);

    if(fd < 0)
    {
        fprintf(stderr, "Failed to open datafile %s %d\n", __FUNCTION__, __LINE__);
        return -1;
    }

	NMEA_GGA_T nmea_gga;
	sscanf(gpsGGA,"%15[^,],%15[^,],%15[^,],%3[^,],%15[^,],%3[^,],%3[^,],%3[^,],%7[^,],%15[^,],%3[^,]",
		nmea_gga.gpstype, nmea_gga.gpstime, nmea_gga.gpslat ,nmea_gga.gpslatpos,
		nmea_gga.gpslong, nmea_gga.gpslongpos, nmea_gga.gpsfix, nmea_gga.gpssat, 
		nmea_gga.gpshoz, nmea_gga.gpsalt, nmea_gga.gpsaltM);

	// Only collect GPS_GGA data if Valid and more than 4 satellites in sight
	sscanf(nmea_gga.gpsfix,"%d", &satfix);
	sscanf(nmea_gga.gpssat,"%d", &satnum);

	if( (satfix > 0) && (satnum > 4) )
	{
#ifdef UNITTEST

#else
		logging(DBG_DETAILED,"%s %s %s %s %s %s %s %s %s\n", nmea_gga.gpslong ,nmea_gga.gpslongpos,
			nmea_gga.gpslat, nmea_gga.gpslatpos, nmea_gga.gpsfix, nmea_gga.gpssat, 
			nmea_gga.gpshoz, nmea_gga.gpsalt, nmea_gga.gpsaltM);
#endif

		sprintf(logbuf,"%ld,%s,%s,%s,%s\n", (long) now, nmea_gga.gpslat,
			nmea_gga.gpslatpos, nmea_gga.gpslong, nmea_gga.gpslongpos);

		write(fd,(char *) &logbuf, strlen((char *) &logbuf)); 
	}
	else
	{
		sprintf(logbuf,"%ld,NA\n", (long) now);
		write(fd,(char *) &logbuf, strlen((char *) &logbuf)); 
	}

	close(fd);

}

int store_gps_RMC(char *gpsRMC)
{
	char logbuf[128];
    char datafiletime[64];
    char datafilename[64];
    char timebuf[32];
	struct tm ts;
	char satwarn[] = "N/A";

	time_t now = time(NULL);
 
    sprintf((char *) &datafilename[0], "/tmp/rfrain_gps.txt");

	int fd;
    fd = open( (char *) &datafilename , O_RDWR | O_APPEND | O_CREAT, 0666);

    if(fd < 0)
    {
        fprintf(stderr, "Failed to open datafile %s %d\n", __FUNCTION__, __LINE__);
        return -1;
    }

	NMEA_RMC_T nmea_rmc;
	sscanf(gpsRMC,"%15[^,],%15[^,],%3[^,],%15[^,],%3[^,],%15[^,],%3[^,],%15[^,],%15[^,],%15[^,]",
		nmea_rmc.gpstype, nmea_rmc.gpstime, nmea_rmc.gpswarn, nmea_rmc.gpslat, nmea_rmc.gpslatpos,
		nmea_rmc.gpslong, nmea_rmc.gpslongpos, nmea_rmc.gpsspeed, nmea_rmc.gpscourse, nmea_rmc.gpsdate);

	// Only collect GPS_RMC data if Warning = A 
	if(0 == strncmp(nmea_rmc.gpswarn,"A",1))
	{
#ifdef UNITTEST

#else
		logging(DBG_DETAILED,"%s %s %s %s %s\n", nmea_rmc.gpslong ,nmea_rmc.gpslongpos,
			nmea_rmc.gpslat, nmea_rmc.gpslatpos, nmea_rmc.gpswarn);
#endif

		sprintf(logbuf,"%ld,%s,%s,%s,%s,%s\n", (long) now, nmea_rmc.gpslat,
			nmea_rmc.gpslatpos, nmea_rmc.gpslong, nmea_rmc.gpslongpos,nmea_rmc.gpsspeed);

		write(fd,(char *) &logbuf, strlen((char *) &logbuf)); 
	}
	else
	{
		sprintf(logbuf,"%ld,NA\n", (long) now);
		write(fd,(char *) &logbuf, strlen((char *) &logbuf)); 
	}

	close(fd);

}
