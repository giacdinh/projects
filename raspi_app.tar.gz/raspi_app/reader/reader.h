#ifdef USEHOST
#define READER_SERIAL_DEV "/dev/ttyUSB0"
#else
#define READER_SERIAL_DEV "/dev/ttyAMA0"
#endif
