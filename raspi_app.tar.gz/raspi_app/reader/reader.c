#include <mysql/mysql.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <string.h>
#include <fcntl.h>
#include <termios.h>
#include <sys_msg.h>
#include <unistd.h>
#include <errno.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include "tm_reader.h"
#include "serial_reader_imp.h"
#include "reader.h"
#include "RDB_reader/RDB_reader.h"
#include "version.h"

#ifdef USE_TM_READER
#include "tmr_utils.h"
#include "TM_reader/inc/reader.h"
#endif

#define HANDHELD_READ_FREQ	1
 
#ifdef UNIT_DEBUG
#define DBG_READER  1
#else
#define DBG_READER  10
#endif


void reader_msg_handler(READER_MSG_T *Incoming);
int reader_read_tag();
void *reader_dog_bark_task();
int reader_to_dbase(char *, int, int, int, int);
int reader_set_single_ant(int port, int ant);
int reader_read_block_tag( );
int check_repeat_cmd_status();
int handheld_read();

extern int reader_set_serial(int fd, int speed);

#ifdef USE_TM_READER
static TMR_ReadPlan plan;
static TMR_Reader ReadPlan;
static TMR_Reader *pReadplan = NULL;
static unsigned char antPort[4] ={1,2,3,4};
static int antCnt = 1;
static int TM_read_power = 3000;	//Default to max power
static int TM_read_region = TMR_REGION_NA;	// Default to NorthAmerica = 1
#endif

int initReaderPlan()
{
#ifdef USE_TM_READER
	bzero((char *) &plan, sizeof(TMR_ReadPlan));
	bzero((char *) &ReadPlan, sizeof(TMR_Reader));
#endif
	return 0;
}

void *reader_main_task()
{
    READER_MSG_T reader_msg;
	logging(DBG_INFO, "Create reader message\n");
	int msgid = create_msg(READER_MSGQ_KEY);
	pthread_t reader_wd_id = -1;
	int result;
	
	if(msgid < 0)
	{
		printf("Failed to create reader message queue\n");
		return 0;
	}	

	initReaderPlan( );

    /* Create thread for DBASE WD response */
    if(reader_wd_id == -1)
    {
        result = pthread_create(&reader_wd_id, NULL, reader_dog_bark_task, NULL);
        if(result == 0)
            logging(DBG_DETAILED, "Starting reader dog bark thread.\n");
        else
            logging(DBG_ERROR, "Reader WD thread launch failed\n");
    }

//	single thread doesn't need joined
//    (void) pthread_join(reader_wd_id, NULL);

	while(1) {
        recv_msg(msgid, (void *) &reader_msg, sizeof(READER_MSG_T), MSG_TIMEOUT);
        reader_msg_handler((READER_MSG_T *) &reader_msg);
        usleep(GENERIC_MSG_HANDLE_DELAY);
	}

	return (void *) 0;
}

void *reader_dog_bark_task()
{
    while(1) {
        send_dog_bark(READER_MODULE_ID);
        sleep(1);
    }
}

void reader_msg_handler(READER_MSG_T *Incoming)
{
    logging(DBG_DETAILED, "%s %d: *** Incoming->modname: %s ***\n", 
		__FUNCTION__, __LINE__, modname[Incoming->header.moduleID]);
    switch(Incoming->header.subType)
    {
		case MSG_MOBILE_SCAN_TAG:
			reader_read_block_tag();
	    break;

		case MSG_REMOTEM_TAG_READ:
			logging(DBG_DETAILED,"Read tag single\n");
			reader_read_block_tag(1);
	    break;
		case MSG_REMOTEM_REPEAT_READ:
			logging(DBG_DETAILED,"Read tag repeat\n");
			reader_read_block_tag(10000);
	    break;
		case MSG_REMOTEM_CONFIG_SET_POWER:
			logging(DBG_EVENT,"Config set power\n");
#ifdef USE_TM_READER
			TM_read_power = Incoming->value;			
#endif
	    break;
		case MSG_REMOTEM_CONFIG_SET_REGION:
			logging(DBG_EVENT,"Config set power\n");
#ifdef USE_TM_READER
			TM_read_region = Incoming->value;			
#endif
	    break;

		case MSG_REMOTEM_HANDHELD_READ:
		case MSG_CTRL_HANDHELD_READ:
			logging(DBG_EVENT,"%s %d: Handheld read\n", __FUNCTION__, __LINE__);
#ifdef USE_TM_READER
			logging(1,"%s: None support command\n", __FUNCTION__);
#else
			handheld_read();
#endif
	    break;

		case MSG_SU_SHUTDOWN:
			logging(DBG_READER,"%s %d:Receive shutdown request for SU process\n", __FUNCTION__, __LINE__);
			sleep(10);
			break;

        default:
            logging(DBG_INFO, "%s: Unknown message type %d\n",__FUNCTION__, Incoming->header.subType);
            break;
    }
}


/***********************************************************************************
 * Start reader hardware dependence code
 * Each reader hardware (Ex: Thingmagic, Rodinbell) will need it own SDK to read tag
 *
***********************************************************************************/

int reader_set_single_ant(int port, int ant)
{
#ifdef USE_TM_READER
	int i;
	for(i=0; i < 4; i++)
	{
		if(i == 0)
			antPort[i] = port;
		else
			antPort[i] = 0;
	}
	antCnt = 1;
#endif
	return 0;
}

int reader_set_multi_ant(unsigned char *antList, int antListCnt)
{
#ifdef USE_TM_READER
	int i;
	for(i=0; i < 4; i++)
	{
		if(*antList != 0)
			antPort[i] = *antList;
		else
			antPort[i] = 0;

		antList++;
	}

	antCnt = antListCnt; 
#endif
	return 0;
}

int reader_block_tags_to_dbase(int tagcount, char *tagpool)
{
    int msg_queue_id;
    DBASE_MSG_T dbase_msg;
    bzero(&dbase_msg, sizeof(DBASE_MSG_T));
    dbase_msg.header.moduleID = READER_MODULE_ID;
    dbase_msg.header.subType = MSG_TAG_MOBILE_READ;
    dbase_msg.tagcnt = tagcount;
    memcpy(dbase_msg.Tagpool, tagpool, TAGPOOL_SZ);

    // Open message queue for dbase and send over
    msg_queue_id = open_msg(DBASE_MSGQ_KEY);
    if(msg_queue_id < 0)
    {
        logging(DBG_ERROR, "Error invalid message queue\n");
        return -1;
    }

    if(0 == send_msg(msg_queue_id, (void *) &dbase_msg, sizeof(DBASE_MSG_T), 3))  
        logging(DBG_DETAILED, "Success send message queue\n");
	else
        logging(DBG_ERROR, "Error failed message queue\n");

	return 1;
}

int reader_read_block_tag(int count)
#ifdef USE_TM_READER
{
	TMR_Reader r, *rp;
	TMR_Status ret;
	TMR_ReadPlan plan;
	TMR_Region region;
	uint8_t antennaList[] = {1,2,3,4};
	uint8_t buffer[20];
	uint8_t i;
	uint8_t antennaCount = 4;
	TMR_String model;
	char str[64];
	TMR_TRD_MetadataFlag metadata = TMR_TRD_METADATA_FLAG_ALL;
    int tagcnt = 0;
    char *pTag, *pTaghead,tempTag[64];
	static char localtag[TAGPOOL_SZ];

	logging(1, "TM reader\n");

	rp = &r;

	//ret = TMR_create(rp, argv[1]);
	if(TMR_SUCCESS != TMR_create(rp, "tmr:///dev/ttyAMA0"))
	{
		logging(DBG_ERROR,"TMR reader create failed\n");
		return -1;
	}

	if(TMR_SUCCESS != TMR_connect(rp))
	{
		logging(DBG_ERROR,"TMR reader connect failed\n");
		return -1;
	}

	region = TM_read_region; //TMR_REGION_EU;
	if(TMR_SUCCESS != TMR_paramSet(rp, TMR_PARAM_REGION_ID, &region))
	{
		logging(DBG_ERROR,"TMR reader set region failed\n");
		return -1;
	}
 
    int value;
    value = TM_read_power;
    if(TMR_SUCCESS != TMR_paramSet(rp, TMR_PARAM_RADIO_READPOWER, &value))
	{
		logging(DBG_ERROR,"TMR reader set power failed\n");
		return -1;
	}
	
	if (rp->readerType == TMR_READER_TYPE_SERIAL)
	{
		if(TMR_SUCCESS != TMR_paramSet(rp, TMR_PARAM_METADATAFLAG, &metadata))
	{
		logging(DBG_ERROR,"TMR reader set metadata failed\n");
		return -1;
	}
	}
 
	// initialize the read plan 
	if(TMR_SUCCESS != TMR_RP_init_simple(&plan, antennaCount, antennaList, TMR_TAG_PROTOCOL_GEN2, 1000))
	{
		logging(DBG_ERROR,"TMR reader init failed\n");
		return -1;
	}
 
	/* Commit read plan */
	if(TMR_SUCCESS != TMR_paramSet(rp, TMR_PARAM_READ_PLAN, &plan))
    {
        logging(DBG_ERROR,"TMR reader set readplan failed\n");
        return -1;
    }

	for(;;)
	{
		ret = TMR_read(rp, 100, NULL);
 
		if (TMR_ERROR_TAG_ID_BUFFER_FULL == ret)
		{
			fprintf(stdout, "reading tags:%s\n", TMR_strerr(rp, ret));
		}
		else
		{
			//checkerr(rp, ret, 1, "reading tags");
		}

		bzero(&localtag[0], TAGPOOL_SZ);
		pTag = (char *) &localtag[0];

		while (TMR_SUCCESS == TMR_hasMoreTags(rp))
		{
			TMR_TagReadData trd;
			char epcStr[128];
			char timeStr[128];
 
			ret = TMR_getNextTag(rp, &trd);
			//checkerr(rp, ret, 1, "fetching tag");
 
			TMR_bytesToHex(trd.tag.epc, trd.tag.epcByteCount, epcStr);
			sprintf(&tempTag[0], "%s %d %d %d %d\n", epcStr, trd.tag.epcByteCount,
						trd.antenna, trd.rssi, trd.frequency);

			memcpy(pTag, &tempTag[0], strlen(&tempTag[0]));
			pTag += strlen(&tempTag[0]);
			tagcnt++;
		}

		// Send message to database to start process read tags
		if(tagcnt > 0)
		{
			reader_block_tags_to_dbase(tagcnt, &localtag[0]);
			// reset tag cnt after send, ready for next loop
			tagcnt = 0;
		}

		if(!check_repeat_cmd_status())
			break;
	}
 
	TMR_destroy(rp);
	return 0;
}

// Using RodinBell reader
#else
{
	logging(1,"Read tag Rodinbell\n");
    static int RDB_serial_port_init = -1;
    RASPI_TAG_T raspi_tag;
    static int fd = -1;
    int tagcnt = 0;
	int i,j;
    char *pTag;
	static char localtag[TAGPOOL_SZ];

    if(fd == -1 && RDB_serial_port_init == -1)
    {
        fd = open(READER_SERIAL_DEV, O_RDWR);
        if( fd < 0)
        {
                //logging(LOG_ERROR, "Serial port open failed\n");
                printf("Failed to open serial port: %s\n", READER_SERIAL_DEV);
                return -1;
        }

        if( 0 > reader_set_serial(fd, B115200))
                printf("Failed to setup serial port\n");

		RDB_serial_port_init = 1;
    }

    // Set single antenna, read tag and store to use
	int host_error;
	host_error = host_cmd_set_ant(fd, 1);
	if(host_error > 0)
		logging(DBG_ERROR, "RDB set ant error: %d\n", host_error);
	else
		logging(DBG_DETAILED,"Set read ant\n");

    for( ;  ; )
	{
#ifdef USE_FOUR_PORT_READER
    	//host_cmd_read_single_port(fd);
		//host_process_read_single_port(fd, &raspi_tag, &tagcnt);
		host_cmd_read_time_inventory(fd);
		host_process_read_single_ant(fd, &raspi_tag);
#else
		host_cmd_read_all_ants(fd);
		host_process_read_all_ants(fd, &raspi_tag);
#endif
		bzero(&localtag[0], TAGPOOL_SZ);
		pTag = (char *) &localtag[0];

		if(raspi_tag.tagCnt > 0)
		{
			logging(DBG_EVENT,"%s %d: read %d tags\n", __FUNCTION__, __LINE__, raspi_tag.tagCnt);
			for(i=0; i < raspi_tag.tagCnt; i++)
			{
				memcpy(pTag, raspi_tag.Tags[i], strlen(raspi_tag.Tags[i]));
				//logging(DBG_EVENT,"%s %d: Tag %s", __FUNCTION__, __LINE__, pTag);
				pTag += strlen(raspi_tag.Tags[i]);
			}
		    
			// Send message to database to start process read tags
			reader_block_tags_to_dbase(raspi_tag.tagCnt, &localtag[0]);
		}
		else	
			logging(DBG_EVENT,"No tags read\n");

		if(!check_repeat_cmd_status())
			break;
	}

	return 0;
}

#endif

int check_repeat_cmd_status()
{
	if(access("/tmp/repeat_read", 0) == 0)
		return 1;
	else
	{
		logging(DBG_EVENT,"Stop reading\n");
		return 0;
	}
}

#ifdef USE_TM_READER

#else
int handheld_read()
{
    static int RDB_serial_port_init = -1;
    RASPI_TAG_T raspi_tag;
    static int fd = -1;
    int tagcnt = 0;
	int i,j;
    char *pTag;
	static char localtag[TAGPOOL_SZ];

	logging(DBG_INFO,"%s %d: Entering ...\n", __FUNCTION__, __LINE__);

    if(fd == -1 && RDB_serial_port_init == -1)
    {
        fd = open(READER_SERIAL_DEV, O_RDWR);
        if( fd < 0)
        {
                //logging(LOG_ERROR, "Serial port open failed\n");
                logging(DBG_ERROR,"%s %d: Failed to open serial port: %s\n",__FUNCTION__, __LINE__,READER_SERIAL_DEV);
                return -1;
        }

        if( 0 > reader_set_serial(fd, B115200))
                logging(DBG_ERROR,"%s %d: Failed to setup serial port: %s\n",__FUNCTION__, __LINE__,READER_SERIAL_DEV);

		RDB_serial_port_init = 1;
    }

    // Set single antenna, read tag and store to use
	int host_error;
	host_error = host_cmd_set_ant(fd, 1);
	if(host_error > 0)
		logging(DBG_ERROR, "RDB set ant error: %d\n", host_error);
	else
		logging(DBG_DETAILED,"Set read ant\n");

    for(int j=0;j < HANDHELD_READ_FREQ;j++)
	{
		host_cmd_read_time_inventory(fd);
		host_process_read_single_ant(fd, &raspi_tag);
		bzero(&localtag[0], TAGPOOL_SZ);
		pTag = (char *) &localtag[0];

		if(raspi_tag.tagCnt > 0)
		{
			for(i=0; i < raspi_tag.tagCnt; i++)
			{
				memcpy(pTag, raspi_tag.Tags[i], strlen(raspi_tag.Tags[i]));
				logging(DBG_EVENT,"%s %d: Tag %s", __FUNCTION__, __LINE__, pTag);
				pTag += strlen(raspi_tag.Tags[i]);
			}
		    
			// Send message to database to start process read tags
			reader_block_tags_to_dbase(raspi_tag.tagCnt, &localtag[0]);
		}
		else	
			logging(DBG_EVENT,"No tags read\n");
		usleep(250000);
	}

	return 0;
}
#endif
