#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h> 
#include <termios.h>
#include <unistd.h>
#include <string.h>

#include "RDB_reader.h"
#include "RDB_error.h"

//#define SINGLE_ANTENNA	1

#define READER_SERIAL_DEV "/dev/ttyAMA0"
#define EPC_12BYTE 12	

int unit_test_case(int fd);
int host_process_read_single_ant(int fd, RASPI_TAG_T *raspi_tag);

int logging(int level, char* logstr, ...)
{
	
}

int set_serial(int fd, int speed)
{
    struct termios tty;

    if (tcgetattr(fd, &tty) < 0) {
        printf("Error from tcgetattr: %s\n", strerror(errno));
        return -1;
    }

    cfsetospeed(&tty, (speed_t)speed);
    cfsetispeed(&tty, (speed_t)speed);

    tty.c_cflag |= (CLOCAL | CREAD);    /* ignore modem controls */
    tty.c_cflag &= ~CSIZE;
    tty.c_cflag |= CS8;         /* 8-bit characters */
    tty.c_cflag &= ~PARENB;     /* no parity bit */
    tty.c_cflag &= ~CSTOPB;     /* only need 1 stop bit */
    tty.c_cflag &= ~CRTSCTS;    /* no hardware flowcontrol */

    /* setup for non-canonical mode */
    tty.c_iflag &= ~(IGNBRK | BRKINT | PARMRK | ISTRIP | INLCR | IGNCR | ICRNL | IXON);
    tty.c_lflag &= ~(ECHO | ECHONL | ICANON | ISIG | IEXTEN);
    tty.c_oflag &= ~OPOST;

    /* fetch bytes as they become available */
    tty.c_cc[VMIN] = 1;
    tty.c_cc[VTIME] = 1;

    if (tcsetattr(fd, TCSANOW, &tty) != 0) {
        printf("Error from tcsetattr: %s\n", strerror(errno));
        return -1;
    }
    return 0;
}

int main()
{
	int fd = -1, wbyte,rbyte;
	unsigned char cmd[64];
	unsigned char rsp[64];
	char version[16];
#ifdef SINGLE_ANTENNA
	printf("Single port reader\n");
#else
	printf("Multi port reader\n");
#endif

	fd = open(READER_SERIAL_DEV, O_RDWR);
	if( fd < 0)
	{
		//logging(LOG_ERROR, "Serial port open failed\n");
		printf("Failed to open serial port\n");
		return -1;
	}

	if( 0 > set_serial(fd, B115200))
		printf("Failed to setup serial port\n");

	unit_test_case(fd);
}


int	unit_test_case(int fd)
{
	char version[16];
	int error;
	RASPI_TAG_T raspi_tag;
	// reset
	//host_cmd_reset(fd);

	// get version
	//host_cmd_version(fd,&version[0]);
	//printf("version: %s\n", &version[0]);

	// ant ID
	//host_cmd_set_ant(fd, 3);

	//int getantid;
	//host_cmd_get_ant(fd, &getantid);
	//printf("Get antid: %d\n", getantid+1);

	// set power
	//host_cmd_set_power(fd, 33);

	// get power
	//int power;
	//host_cmd_get_power(fd,&power);
	//printf("Get ant power: %d\n", power);

	// Freq region NA set
	//host_cmd_set_region_NA(fd);

	// region get
	//int region;
	//host_cmd_get_region(fd, &region);
	//printf("Get region: %d\n", region);

	// temperature get
	//int temperature;
	//host_cmd_get_temperature(fd, &temperature);
	//printf("Get temperature: %d\n", temperature);

	// gpio get
	//int gpio1, gpio2;
	//host_cmd_get_gpio(fd, &gpio1, &gpio2);
	//printf("Get gpio1: %d gpio2: %d\n", gpio1, gpio2);

	// gpio set
	//host_cmd_set_gpio(rd, 0x03, 1);

	// antenna detect set
	//host_cmd_set_ant_detect(fd);

	// set reader ID
	//host_cmd_set_reader_id(fd);
	//printf("Done reader id set\n");

	// get reader ID
	//unsigned char readerID[16];
	//host_cmd_get_reader_id(fd, &readerID[0]);
	//for(int i=0; i < 12; i++)
	//	printf("0x%02x ", readerID[i]);

	// set rflink profile
	//host_cmd_set_rflink_profile(fd, 0x0D);

	// get rflink profile
	//unsigned char profileID;
	//host_cmd_get_rflink_profile(fd, &profileID);
	//printf("Get profileID: 0x%02x\n", profileID);

	// To read set antenna then read
	//error = host_cmd_set_ant(fd, 0x01);
	//if(error > 0)
	//printf("Set ant failed error: %d\n", error);
#ifdef SINGLE_ANTENNA
	host_cmd_read_time_inventory(fd);
	host_process_read_single_ant(fd, &raspi_tag);
#else
	host_cmd_read_all_ants(fd);
	host_process_read_all_ants(fd, &raspi_tag);
#endif
	printf("Read %d tag\n", raspi_tag.tagCnt);
	int i;
	for(i=0; i < raspi_tag.tagCnt; i++)
		printf("%s", raspi_tag.Tags[i]);
	
	// To read set antenna then read
	//host_cmd_read_all_ants(fd);
	//host_process_read_all_ants(fd, &raspi_tag);
}
