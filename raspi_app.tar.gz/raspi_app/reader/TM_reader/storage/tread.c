/**
 * Sample program that reads tags for a fixed period of time (500ms)
 * and prints the tags found.
 * @file read.c
 */

#include "tm_reader.h"
#include "tmr_utils.h"
#include "serial_reader_imp.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <inttypes.h>
#include "common.h"

int main()
{
    int SDKErr;
    int i, antCnt = 1;
    int numofTag = 0;
    unsigned char *pAntList;
    TagDevEPCStruct Taglist[100];
    API_STATUS run_status = 0;
    TMR_Reader Readplan, *pReadplan;
    TMR_ReadPlan plan;
    char epcStr[128];
    TMR_TRD_MetadataFlag metadata = TMR_TRD_METADATA_FLAG_ALL;
 
    pReadplan = &Readplan;
    run_status = m6e_Port_Open(pReadplan, &SDKErr);
    if(run_status > API_SUCCESS)
    {
	printf("Failed port open\n");
        return -1;
    }
    run_status = m6e_Port_Connect(pReadplan, &SDKErr);
    if(run_status > API_SUCCESS)
    {
	printf("Failed port connect\n");
        return -1;
    }

    run_status = setRegion(pReadplan, TMR_REGION_NONE, &SDKErr);
    if(run_status > API_SUCCESS)
    {
	printf("Failed set region\n");
        return -1;
    }
    run_status = checkSupportAntenna(pReadplan, &SDKErr);
    if(run_status > API_SUCCESS)
    {
	printf("Failed check antenna\n");
        return -1;
    } 

    unsigned char antList[4] = {1,0,0,0};

    pAntList = (unsigned char *) &antList;  

    run_status = setupAntenna(pReadplan,antCnt, pAntList, &SDKErr);
    if(run_status > API_SUCCESS)
    {
	printf("setup antenna error\n");
	return 0;
    }

    run_status = Commit_ReadPlan(pReadplan, &plan, &metadata, &SDKErr);
    if(run_status > API_SUCCESS)
    {
	printf("Commit plan error\n");
	return 0;
    }
 
    run_status = readTagDisc(pReadplan,(TagDevEPCStruct *) &Taglist,&numofTag,&SDKErr);
    if(run_status > API_SUCCESS)
    {
	printf("Read tag failed\n");
	return 0;
    }

    printf("Tags read: %d\n", numofTag);
	for(i=0; i < numofTag; i++)
	{
		TMR_bytesToHex(Taglist[i].tag, Taglist[i].EPCLen, epcStr);
		printf("%s: %s ant: %d rssi: %d\n", __FUNCTION__,
			epcStr, Taglist[i].antid, Taglist[i].rssi);
	}

}
