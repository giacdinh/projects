

#define GENERAL_RESPONSE_HEADER "HTTP/1.0 200 OK\r\n\
Content-type: text/plain; charset=iso-8859-1\r\n\r\n"


#define REMOTEM_TAG_READ "remotem_tag_read.cgi"
#define REMOTEM_SET_ANTENNA "remotem_set_antenna.cgi"
