#include <stdio.h>
#include <time.h>
#include <string.h>
#include <sys_msg.h>
#include <unistd.h>
#include <pthread.h>

#ifdef UNIT_DEBUG
#define DBG_SU  1
#else
#define DBG_SU  10
#endif

void *su_dog_bark_task();
void su_msg_handler(SU_MSG_T *Incoming);

void *su_main_task()
{
	int result = -1;
	pthread_t su_wd_id = -1;

    logging(DBG_INFO, "%s: Entering ...\n", __FUNCTION__);

    SU_MSG_T su_msg;
	logging(DBG_INFO, "Create controller message\n");
	int msgid = create_msg(SU_MSGQ_KEY);
	
	if(msgid < 0)
	{
		logging(DBG_ERROR,"Failed to create controller message queue\n");
		return 0;
	}	

	/* Create thread for SU WD response */
	if(su_wd_id == -1)
	{
		result = pthread_create(&su_wd_id, NULL, su_dog_bark_task, NULL);
        if(result == 0)
	        logging(DBG_DETAILED, "Starting su dog bark thread.\n");
        else
            logging(DBG_ERROR, "SU WD thread launch failed\n");
	}

	while(1) {
        recv_msg(msgid, (void *) &su_msg, sizeof(SU_MSG_T), MSG_TIMEOUT);
        su_msg_handler((SU_MSG_T *) &su_msg);
        usleep(GENERIC_MSG_HANDLE_DELAY);
	}

	return (void *) 0;
}

void *su_dog_bark_task()
{
    while(1) {
        send_dog_bark(SU_MODULE_ID);
        sleep(1);
    }
}

void su_msg_handler(SU_MSG_T *Incoming)
{
	SU_MSG_T *ctrl_msg;
    logging(DBG_INFO, "**** Incoming->modname: %s ****\n", modname[Incoming->header.moduleID]);
	
    switch(Incoming->header.subType)
    {
		case MSG_SU_START:
			// Handle software update
			nice(-20);
			logging(1,"receiving software upgrade request: %s\n", Incoming->filename);
			break;

        default:
            logging(DBG_INFO, "%s: Unknown message type %d\n",__FUNCTION__, Incoming->header.subType);
            break;
    }
}

int su_send_reader_msg(int msg_id)
{
    READER_MSG_T reader_msg;
    bzero((char *) &reader_msg, sizeof(READER_MSG_T));

    int msg_queue_id = open_msg(READER_MSGQ_KEY);
    if(msg_queue_id < 0)
    {
		logging(DBG_ERROR, "%s %d:Error invalid message queue\n",__FUNCTION__, __LINE__);
        return -1;
    }

    reader_msg.header.subType = msg_id;
    reader_msg.header.moduleID = SU_MODULE_ID;
    send_msg(msg_queue_id, (void *) &reader_msg, sizeof(READER_MSG_T), 3);

    return 0;
}


