#!/bin/sh
openssl req -nodes -new -x509 -extensions v3_ca -keyout private/root-key.pem -out root-cert.pem -days 3650 -config ./root.cnf

