#!/bin/sh
openssl req -nodes -new -extensions v3_ca -keyout fact-key.pem -out fact-req.pem -days 3650 -config ./root.cnf
openssl ca -out fact-cert.pem -config ./root.cnf -infiles fact-req.pem


