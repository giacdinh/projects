#!/bin/sh
openssl req -nodes -new -keyout unit-key.pem -out unit-req.pem -days 3650 -config ./factory.cnf
openssl ca -out unit-cert.pem -config ./factory.cnf -infiles unit-req.pem


