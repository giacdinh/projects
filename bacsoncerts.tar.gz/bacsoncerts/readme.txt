These scripts are used to generate the certificates that are needed to run
the security subsystem.  They are installed into the system using the 
'buildrom' tool, which generates a ROM image that can be burned into a
Flashback 2 system.

Two configuration files are used to generate certificates:

1.  root.cnf is the configuration file which is used to generate the
self-signed root certificate, the factory certificate, and the software
upgrade certificate.

2.  factory.cnf is the configuration file which is used (typically at the
factory) to generate the unit certificate(s) and the remote management
certificate(s).

The order of operations is as follows:

1.  use 'mkroot.sh' to generate the root certificate
2.  use 'mkfactory.sh' to generate the factory certificate
3.  use 'mksu.sh' to generate the software upgrade certificate

Then, for each Flashback 2 unit,

1.  use 'mkunit.sh' to generate a unit certificate
2.  use 'buildrom' to incorporate the generated certificates into the ROM image

Also, for each remote management server,

1.  use 'mkremote.sh' to generate a remote management certificate

Upon execute any of the .sh scripts, you will be prompted to enter the
"Organization Name" and the "Common Name"

Common Name is typically a descriptive name for the certificate.  In the case
of the unit certificate, it should be of the form "FB_00000000" where
00000000 can be substituted with any 8 digit hex number.

